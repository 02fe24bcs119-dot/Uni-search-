# Security design and deployment cautions

- Login returns a 15-minute JWT. The frontend stores it in sessionStorage for a local academic demonstration. For production security prefer a server-managed secure HttpOnly SameSite session with CSRF defense, TLS, logout/revocation and security monitoring.
- All document listing/search/download handlers use the current authenticated database user. Admins can see all documents. PUBLIC/UNIVERSITY are visible to authenticated users. DEPARTMENT is visible only to matching department users. RESTRICTED/PRIVATE belong to the uploader or admin.
- Never trust frontend role checks for authorization. Mutations are allowed only to document owner/admin, and monitoring endpoints require admin.
- Access to raw stored filenames and the original filesystem paths is not exposed in list/search JSON. Download handlers use server-generated UUID filenames, controlled MIME types and `nosniff`.
- Uploaded content is checked by format/structure and limited by file size and batch count. This is not an antivirus scanner; for institutional production add AV scanning, strict content isolation and stronger ZIP bomb bounds.
- SQL uses parameterized MySQL queries; dynamically constructed `IN` placeholders are generated from validated arrays, never from user SQL strings.
- Original file bytes remain on local disk, outside the frontend static directories. Back up disk storage and MySQL together; review partial file-cleanup errors.
- Failures are logged without stack traces in API responses. Audit login/registration/admin changes and record key document actions; add retention and privacy policy before production.
- MySQL grants should use an application user with only the necessary permissions and a separate migration account. Do not ship production root credentials. Keep `.env` and JWTs private.
- Three-worker coordinator assumes **one backend parent server instance**. For multi-replica deployment, use a more advanced leased queue with worker ownership fencing tokens; do not horizontally scale this parent unchanged.
- A scanned PDF without usable native text requires local `pdftoppm` and `tesseract`; the OCR fallback is bounded by configured page count and timeouts. The extraction of very large ZIP internals should be further hardened for hostile documents.
- The `PUBLIC` label is still authenticated-only in this version. Only users with accounts can list or download files.
