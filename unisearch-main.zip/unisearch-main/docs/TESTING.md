# Verification / Gate-1 acceptance checklist

## Verification completed in the packaging environment

- Node syntax check of all ESM modules (`node --check`).
- E1 dependency-free text tokenization/positional indexing unit tests.
- E2 Boolean precedence, NOT, phrase adjacency, ranking and page-offset unit tests.
- E3 transaction commit/rollback and input-validation tests using isolated in-memory test doubles **only in tests** (not app data).

All tests can be repeated with `bash scripts/check.sh`. **Do not confuse unit-test fixtures with real documents; the production schema has no default documents/users.**

## Requires installation and a live MySQL instance

These items are **not verified by the packaging environment**:

- `npm install` in the E1, backend, frontend directories and `npm run build` in frontend
- `npm run migrate` on your MySQL 8.0+ server and verifying MySQL primary/foreign keys
- Signing in and uploading real PDF/DOCX/PPTX/TXT documents
- Actual Tesseract OCR on a scanned PDF (requires Tesseract and Poppler)
- True three-worker IPC processing with 5 or 10 real documents and queued remainder
- Killing a worker and observing actual child restart and bounded job retry
- Duplicate hash detection, file replacement and deletion updating postings
- Search remaining available after an API restart
- Role/department access-denial tests and audit trail
- MySQL transaction rollback when a real SQL failure is injected
- Real API p95 query latency and indexing performance across 10/50/100 documents

## Manual acceptance procedure

1. Start MySQL and apply `npm run migrate`; verify `SHOW TABLES;` returns the ten intended tables.
2. Create admin with your own credentials and log in. Confirm a blank library and zero index counts when no documents have been uploaded.
3. Upload a real PDF containing known text, and observe `QUEUED → PROCESSING → INDEXED`. Confirm `terms` and `postings` contain actual rows.
4. Upload a DOCX, PPTX, TXT and scanned PDF (with OCR tools) and check extracted search phrases by comparing returned snippets with original source files.
5. Upload 5 real documents in a single submission. On Engine Monitor observe **exactly three OS child worker PIDs**, at most three `BUSY` jobs, and additional queued jobs; do not infer concurrency from Promise counts.
6. Search for `"machine learning"` and `machine AND learning` after uploading a PDF that really contains these terms; compare search scores, snippets and document IDs with the indexed text.
7. Register a student who is not the owner of a restricted file and confirm that searches, file preview, download and metadata lookup do not expose that file.
8. Upload an identical file twice; verify the second upload reports `DUPLICATE` and creates no new postings.
9. Replace a document with changed content. Verify removed words no longer match, added words do, and there is only one logical `document_id`.
10. Delete a document and verify both the file and its posting records disappear. Run the same search again; it should no longer return that document.
11. Restart the API. The index must remain searchable without reprocessing all existing documents.
12. Terminate one Engine 1 child PID while it is processing a real file; verify it restarts with a new PID, records the failure, and retries no more than the configured attempt limit.
13. Benchmark real search queries using environment variables (below). Record machine, dataset sizes, run count, query set, and p95. Do **not** claim the 2-second NFR until measurement passes.

## Real benchmarking commands

```bash
# Search latency on real uploaded/indexed documents:
export BENCHMARK_TOKEN='<your current JWT locally>'
export BENCHMARK_QUERY='document'
node scripts/benchmark-search.mjs
unset BENCHMARK_TOKEN

# Sequential vs three independent IPC subprocesses with real file paths:
node scripts/benchmark-processing.mjs ~/Documents/real1.pdf ~/Documents/real2.pdf ~/Documents/real3.pdf
```

The second command runs a separate comparison harness. The actual application always maintains exactly 3 document worker processes, regardless of benchmark settings.

## Acceptance criteria trace

| IDs | Expected demonstration |
|---|---|
| FR-01–03 | Real multi-format upload, content preflight, stored original and metadata |
| FR-04–05 | Nonblocking persistent queue, three child-worker IPC processing, extraction |
| FR-06 | Durable MySQL positional index, incremental add/replace/delete |
| FR-07–08 | AND/OR/NOT and quoted phrase, TF-IDF scores, ranked snippets |
| FR-09 | JWT, document and department access enforcement |
| FR-10–11 | Admin workers/jobs/errors/audit, requeue failures |
| FR-12 | Worker/queue metrics exposed (optional scaling not implemented) |
| NFR-01–08 | Performance p95, restart persistence, permissions, 2+ concurrent workers, usable messages, idempotence, robustness, audit testing |

**Outstanding limitations:** Full OCR tests, integration tests with MySQL and a real browser, concurrency stress testing and measured benchmarks must run on a configured machine. No performance numbers are fabricated or asserted here.
