# Implementation status — MySQL edition

## Scope changes from prior Gate-1 starter

- PostgreSQL `pg` and PostgreSQL migrations replaced with MySQL 8/InnoDB, `mysql2/promise`, MySQL DDL and database pooling.
- Engine 1 uses exactly three long-lived Node child processes via `child_process.fork()` and IPC, instead of Python one-shot subprocesses. Independent test verified three separate PIDs receiving five documents via IPC.
- Formats are PDF, DOCX, PPTX and TXT; scanned PDF OCR uses optional native Poppler and Tesseract binaries.
- Engine 2 retained the previously implemented Boolean/phrase positional search, with Top-K pagination, deterministic scores and stopword-free TF-IDF ranking.
- Engine 3 handles all document+job insertions and index mutations transactionally with persistent retry states, SHA-256 deduplication, and updated term document-frequency statistics.
- Engine 4 now includes bulk upload of at most ten files per request, actual upload progress, permitted document CRUD and replacement, home/library/search screens and actual worker PID monitoring.
- The production database is **not seeded** with any users, documents, search records or processing metrics. Every user/document/job/score originates from an actual action. Unit tests construct temporary isolated fixtures and do not connect to production data.

## Executed checks

Command: `bash scripts/check.sh`

- Node ESM syntax checks: completed successfully.
- Node test suite: **24/24 passing** (including 3-process child IPC with five temporary text files).
- JSX syntax transpile check using locally installed TypeScript parser: no syntax diagnostics.
- Confirmed migration declares 10 MySQL tables.

Complete console output is in `docs/VERIFICATION-LOG.txt`.

## NOT verified here — do not claim as complete integration testing

- npm dependency installation and a real Vite production build.
- A connected MySQL 8 service, real schema creation, authenticated API requests and persistence across service restart.
- PDF/DOCX/PPTX extraction (dependencies unavailable at build time), Tesseract OCR on scanned PDF, and end-to-end index retrieval against MySQL.
- Simultaneous backend worker indexing and error/retry behavior against the live MySQL job queue.
- Performance p95 query latency or 10/50/100-document processing benchmarks.

## Compatibility caution

GitHub checkout of the user's existing repository was unavailable due to DNS/network limitations in the packaging environment. Existing working frontend styling and Engine 2 parser from the earlier project archive were reused; other modules were rebuilt. This ZIP is a new project edition, not a patch applied to the live GitHub repository. Use a separate directory until you have reviewed integration changes.
