# REST API — MySQL / Express Engine 4

Base URL: `http://localhost:5001`; JSON success format `{ "success": true, ... }`, error format `{ "success": false, "message": "..." }`. All endpoints except `/api/health`, login and registration require `Authorization: Bearer <JWT>` (15-minute JWT). API request validation and role restrictions are enforced on the server.

| Method | Endpoint | Role | Description |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Student signup: `{ fullName, email, password }`; password 12+ chars |
| POST | `/api/auth/login` | Public | `{email,password}` returns `{data:{accessToken,user}}` |
| GET | `/api/auth/me` | Logged in | Signed-in identity |
| GET | `/api/health` | Public | Actual MySQL connection check; returns 503 on DB failure |
| GET | `/api/departments` | Logged in | Department list (empty until created) |
| POST | `/api/departments` | Admin | `{name}` |
| POST | `/api/documents/upload` | Logged in | Multipart `documents` (1–10 files), plus optional `title`, `description`, `subject`, `semester`, `category`, `accessLevel`, `departmentId`. Also accepts singular `document` for compatibility. 10MB each by default. Returns 202 for full acceptance, 207 for mixed accepted/duplicates, or 409 for duplicates. Response includes `results:[{filename,status,documentId?}]` |
| GET | `/api/documents` | Logged in | Accessible metadata `documents[]`, limit/offset pagination |
| GET | `/api/documents/:id` | Access checked | One document metadata record; no internal stored path |
| GET | `/api/documents/:id/status` | Access checked | Processing status or failure |
| GET | `/api/documents/:id/preview` | Access checked | Inline PDF, attachment for Office/TXT |
| GET | `/api/documents/:id/download` | Access checked | Source file as attachment |
| PATCH | `/api/documents/:id` | Uploader/Admin | Update title, description, accessLevel, departmentId, subject, semester, category |
| PUT | `/api/documents/:id/file` | Uploader/Admin | Multipart `document` replacement, recomputes hash and updates index |
| DELETE | `/api/documents/:id` | Uploader/Admin | Deletes document and postings transactionally, then removes stored file |
| POST | `/api/documents/:id/retry` | Uploader/Admin | Requeues failed/completed document |
| GET | `/api/search` | Logged in | `q`, `limit` default 10, `offset`, optional `subject`, `semester`, `category`, `departmentId`, `fileType=pdf|docx|pptx|txt`. Results include actual `score`, `snippet`, `executionMs`, `total` |
| GET | `/api/workers` | Admin | Current parent PID and real child worker PIDs/statuses |
| GET | `/api/jobs` | Admin | Recent persistent jobs and failures |
| GET | `/api/stats` | Admin | Actual indexed counts, term/postings counts, queue plus live worker status |
| GET | `/api/audit` | Admin | Recent administrative/authentication audit trail |
| GET | `/api/events` | Logged in | Bearer-authenticated SSE `statuses` event for visible document statuses |

## Sample request structure (not sample database records)

```bash
# Add the JWT returned from your real login to the shell variable TOKEN; do not paste it into a public chat.
curl -H "Authorization: Bearer $TOKEN" "http://localhost:5001/api/search?q=%22operating%20systems%22&limit=10"
```

Supported status values: `UPLOADED`, `VALIDATING`, `QUEUED`, `PROCESSING`, `OCR_PROCESSING`, `EXTRACTED`, `INDEXING`, `INDEXED`, `FAILED`. Records start in `QUEUED` after successful preflight and DB insert. The worker parent uses `QUEUED`, `RUNNING`, `RETRY_WAIT`, `SUCCEEDED`, `FAILED` job states. Only `INDEXED` files can appear in search results. Unauthorized document lookups return 404, rather than leaking existence by file ID.

`207 Multi-Status` means some upload files were queued and others were duplicates/invalid at insertion. The front end presents per-file outcomes. Parsing/format validation happens before the batch is accepted, so malformed files return HTTP 400 and zero queued jobs. Maximum query length is 250 Unicode characters; no full-document SQL `LIKE` search is used.
