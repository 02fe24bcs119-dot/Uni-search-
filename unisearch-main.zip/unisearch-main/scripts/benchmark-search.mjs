// Real HTTP API latency. No mock results; requires uploaded/indexed docs and a valid login token.
const base=process.env.BENCHMARK_BASE_URL||'http://localhost:5001'
const token=process.env.BENCHMARK_TOKEN
const query=process.env.BENCHMARK_QUERY
const iterations=Number(process.env.BENCHMARK_ITERATIONS||30)
if(!token||!query||iterations<5||iterations>1000){console.error('Set BENCHMARK_TOKEN, BENCHMARK_QUERY and optionally BENCHMARK_ITERATIONS=30');process.exit(1)}
const durations=[];let lastCount=null
for(let i=0;i<iterations;i++){
 const start=performance.now()
 const response=await fetch(`${base}/api/search?q=${encodeURIComponent(query)}&limit=10`,{headers:{Authorization:`Bearer ${token}`}})
 const result=await response.json()
 if(!response.ok)throw new Error(`${response.status}: ${result.message}`)
 durations.push(performance.now()-start);lastCount=result.total
}
durations.sort((a,b)=>a-b)
const avg=durations.reduce((a,b)=>a+b,0)/iterations
const p95=durations[Math.ceil(iterations*.95)-1]
console.log(JSON.stringify({query,iterations,actual_matching_documents:lastCount,mean_ms:Number(avg.toFixed(2)),p95_ms:Number(p95.toFixed(2)),min_ms:Number(durations[0].toFixed(2)),max_ms:Number(durations.at(-1).toFixed(2))},null,2))
