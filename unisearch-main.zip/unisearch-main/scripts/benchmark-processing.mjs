/** Compare sequential and three-process extraction on actual supplied files.
 * Usage: node scripts/benchmark-processing.mjs /path/doc1.pdf /path/doc2.docx ...
 * This standalone benchmark never accesses the production MySQL DB or fabricates results.
 */
import {fork} from 'node:child_process'
import {fileURLToPath} from 'node:url'
import {resolve,join} from 'node:path'
import {existsSync} from 'node:fs'
const paths=process.argv.slice(2).map(resolve)
if(!paths.length||paths.some(p=>!existsSync(p))){console.error('Supply paths to existing, supported files (10/50/100 when available).');process.exit(1)}
const worker=fileURLToPath(new URL('../engines/engine-1-document-processing/src/worker.mjs',import.meta.url))
async function run(count){
 const queue=[...paths];let completed=0,failed=0;const children=[]
 const started=performance.now()
 return await new Promise((resolveDone,reject)=>{
  let done=false
  function finish(){if(done||completed+failed!==paths.length)return;done=true;for(const child of children)child.send({type:'SHUTDOWN'});resolveDone({workers:count,files:paths.length,completed,failed,seconds:Math.round((performance.now()-started))/1000})}
  for(let n=0;n<count;n++){
   const child=fork(worker,[],{stdio:['ignore','inherit','inherit','ipc']});children.push(child)
   let active=false
   const assign=()=>{if(done||active)return;const path=queue.shift();if(!path){finish();return}active=true;child.send({type:'PROCESS',jobId:completed+failed+1,path,options:{ocrEnabled:true,ocrMaxPages:5}})}
   child.on('message',m=>{if(m.type==='READY')assign();if(m.type==='RESULT'||m.type==='ERROR'){active=false;m.type==='RESULT'?completed++:failed++;assign()}})
   child.on('error',reject)
   child.on('exit',code=>{if(!done&&code!==0)reject(new Error(`Worker unexpectedly exited ${code}`))})
  }
 })
}
const sequential=await run(1),parallel=await run(3)
console.log(JSON.stringify({sequential,parallel,speedup:parallel.seconds?Number((sequential.seconds/parallel.seconds).toFixed(3)):null},null,2))
