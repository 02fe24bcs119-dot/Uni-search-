#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo 'Checking Node module syntax...'
find engines -type f -name '*.mjs' -print0 | xargs -0 -n1 node --check
echo 'Running dependency-free Engine 1, Engine 2 and Engine 3 tests...'
node --test engines/engine-1-document-processing/tests/*.test.mjs engines/engine-2-search-retrieval/tests/search.test.mjs engines/engine-3-persistent-index/tests/repository.test.mjs
echo 'Note: live MySQL, OCR, frontend build and HTTP integration require installed dependencies/services and are NOT covered by this command.'
