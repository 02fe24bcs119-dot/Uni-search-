# Four-engine architecture

```mermaid
flowchart TD
  Browser[React / Vite interface\nEngine 4] --> API[Express API + JWT + SSE\nEngine 4]
  API -->|authenticated upload| Store[(Original files on disk)]
  API -->|create jobs| DB[(MySQL 8+ InnoDB\nEngine 3)]
  API --> Parent[Node API parent process\nEngine 1 coordinator]
  Parent -->|IPC| W1[Child worker 1]
  Parent -->|IPC| W2[Child worker 2]
  Parent -->|IPC| W3[Child worker 3]
  W1 -->|extracted tokens| Indexer[Transactional positional indexing\nEngine 2 + Engine 3]
  W2 -->|extracted tokens| Indexer
  W3 -->|extracted tokens| Indexer
  Indexer --> DB
  API -->|query terms| Search[Boolean + phrase parsing\nTF-IDF + Top K · Engine 2]
  Search -->|authorized postings| DB
  Search --> API
```

## Upload / indexing

```mermaid
flowchart LR
 A[Choose 1–10 real files] --> B[Validate content and hash SHA-256]
 B --> C[Store file + create durable job in MySQL]
 C --> D[Three-worker IPC queue]
 D --> E[Extract / optional Tesseract OCR]
 E --> F[Normalize and create positions]
 F --> G[MySQL atomic index commit]
 G --> H[INDEXED / searchable]
 E -->|error| I[Log failure / retry eligibility]
```

## Search

```mermaid
flowchart LR
 A[User query] --> B[JWT and ACL]
 B --> C[Boolean / phrase parse]
 C --> D[Authorized posting-list candidates in MySQL]
 D --> E[Positional match and TF-IDF]
 E --> F[Top K, snippets and metadata]
 F --> G[React results and authorized file endpoints]
```

## Database ER (MySQL)

```mermaid
erDiagram
  departments ||--o{ users : has
  departments ||--o{ documents : scopes
  users ||--o{ documents : uploads
  documents ||--o{ postings : indexed_in
  terms ||--o{ postings : appears_in
  documents ||--o| document_statistics : tracks
  documents ||--o| document_contents : stores
  documents ||--o| processing_jobs : processed_by
  processing_jobs ||--o{ job_failures : logs
  users ||--o{ audit_events : performs
```

## Engine contracts / ownership

- Engine 1 owns extraction and OS worker coordination. IPC messages are `READY`, `PROCESS`, `STAGE`, `RESULT`, `ERROR`, and `SHUTDOWN`. A result contains `terms`, `document_length`, `extracted_text`, `extraction_method`, format and source size. Only one job is sent to each child at a time.
- Engine 2 owns query grammar, positional phrase matching, and deterministic TF-IDF Top-K ranking. The score formula is: for matching term `t` in document `d`, **(1 + ln(tf(t,d))) × ln(1 + (N + 1)/(df(t) + 1))**, summed over non-stopword query terms. A tie is broken by title and then ID. N is the authorized, indexed corpus size; document frequencies are calculated from authorized postings for the query.
- Engine 3 owns durable metadata and indexed state in MySQL. InnoDB row locks and `SELECT ... FOR UPDATE SKIP LOCKED` claim jobs exactly once. Transactions atomically replace old postings and update statistics, contents, and status. Only `INDEXED` documents enter search.
- Engine 4 owns login, uploading, access control, API request validation, SSE status, user/admin workflows. It must never expose raw stored filenames or document text without user authorization.

## Job lifecycle

`UPLOADED → VALIDATING → QUEUED → PROCESSING → [OCR_PROCESSING] → EXTRACTED → INDEXING → INDEXED` or `FAILED`; retryable failures return to `QUEUED` through `RETRY_WAIT` job state. In this code preflight is completed before the document is recorded, so durable rows start in `QUEUED`. `INDEXED` is only set in the same transaction as the index commit.

## Reliability

Three long-lived child processes run under one parent. Each has an actual PID, status, current job and restart count. If a child exits unexpectedly, its job is marked for retry (bounded), a new child replaces it, and the queue resumes. Startup reclaims jobs from the previous parent. Server shutdown attempts a graceful child shutdown. Files are written before the document+job transaction; failed inserts remove the new file. A successful delete or replacement deletes the old on-disk file after DB commit and logs cleanup errors if it cannot be removed.

Database storage persists through app restart. The filesystem path and database must be backed up together.
