# University Document Search Engine — MySQL / Three Worker Edition

An engine-first academic search application based on the supplied Gate-1 review and the additional four-engine specifications. **No demo documents, seeded search results, random worker metrics, or fabricated scores are included.** The UI starts empty until real users upload files.

## What is built

| Engine | Owned responsibility | Actual implementation |
|---|---|---|
| E1 | Multi-process file processing | Parent-controlled pool of **exactly three Node.js `fork()` child processes**, IPC messages, per-worker active-job limit, failure/restart handling, native PDF/DOCX/PPTX/TXT extraction, optional scanned-PDF Tesseract OCR |
| E2 | Retrieval and ranking | Case-normalized term positions, Boolean AND/OR/NOT, quoted phrases, real inverted postings, document frequency and smoothed TF-IDF, Top-K ranking/pagination |
| E3 | Durable incremental index | **MySQL 8.0+**, InnoDB, relational document/index/job tables, SHA-256 duplicate detection, transactionally replaced positional postings on reindex, affected term DF updates, transactional metadata/update/delete, durable retry queue |
| E4 | Web control | React/Vite responsive web app, Express REST API, JWT authentication, department/role access checks, **up to 10 files per batch** (10 MB each by default), file replacement/deletion, SSE status, admin monitoring of actual child PIDs and states |

**Database change:** the pasted spec says PostgreSQL, but your explicit request overrides it. This version uses **MySQL, not PostgreSQL, throughout**. MySQL has a `university_search` **database**, not a PostgreSQL `unidoc` schema. pgAdmin does **not** manage MySQL; use MySQL Workbench or `mysql` CLI.

The existing GitHub repository could not be fetched in the build environment (DNS/network access was unavailable). This is a **separate rebuild** using earlier conversation-provided project sources for the search algorithm and frontend foundation. It is **not an in-place edit or guaranteed drop-in replacement** for an unseen, newer GitHub checkout. Back up your repository before integrating.

## Requirements on macOS

- Node.js **22+** and npm; `node -v`
- MySQL **8.0+** or **8.4**, running locally or in Docker
- For PDF/DOCX/PPTX libraries: internet connection for `npm install`
- For scanned-PDF OCR: `tesseract` and `pdftoppm` (Poppler)

Homebrew example (run only if not already installed):

```bash
brew install node mysql tesseract poppler
brew services start mysql
mysql --version
```

Optional Docker alternative for only MySQL: set your own `MYSQL_ROOT_PASSWORD`, then `docker compose up -d mysql`. If local MySQL uses 3306 already, do **not** start the second instance on the same port.

## Start your project on Mac

1. Unzip `university-document-search-mysql.zip` into a new directory (do not replace your existing university-document-search repository).
2. Open Terminal and change into the extracted project directory. Run these three installations:

```bash
cd engines/engine-1-document-processing && npm install
cd ../engine-4-search-control-interface/backend && npm install
cd ../frontend && npm install
```

3. Configure backend settings. From `engines/engine-4-search-control-interface/backend`:

```bash
cp .env.example .env
```

Edit `.env` to set your MySQL credentials and a random `JWT_SECRET` (at least 32 characters). Generate a random value with:

```bash
node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
```

**Never commit `.env`, real credentials, tokens or uploaded documents.**

4. **Create all MySQL tables automatically** from the backend folder:

```bash
npm run migrate
```

The migration creates the `university_search` MySQL database if it does not exist, and ten relational tables. For a database already containing tables from an older incompatible MySQL edition, take a backup and review migration differences before running it; `IF NOT EXISTS` does not upgrade old table shapes. It needs a MySQL user with permission to create the database and tables. It does not erase existing documents. If you are migrating from PostgreSQL, this creates a *new MySQL database*; it does not import existing PostgreSQL rows. Existing real documents must be migrated separately with their permissions and index references.

5. **Create the first administrator** explicitly using environment variables and your own credentials (no built-in account is seeded):

```bash
export ADMIN_EMAIL='admin@your-university.edu'
export ADMIN_NAME='University Administrator'
read -s ADMIN_PASSWORD
export ADMIN_PASSWORD
npm run seed:admin
unset ADMIN_PASSWORD
```

Type your private password when `read -s` waits for input; nothing will be shown. The password must have at least 12 characters. To set an existing student's role later, use `npm run set-role -- user@school.edu FACULTY` from the backend. Protect operating-system access to this CLI.

6. Start the API **from the backend folder**:

```bash
npm run dev
```

Expected: API address `http://localhost:5001` and **exactly three Node child workers** spawned. If MySQL is unavailable, the server fails rather than showing fake healthy status.

7. In a **second terminal**, from `engines/engine-4-search-control-interface/frontend`:

```bash
cp .env.example .env
npm run dev
```

Open `http://localhost:5173`. Log in with your administrator account, or register a student. Search starts empty until actual documents are uploaded and indexed. Confirm the database from **MySQL Workbench** using connection host `127.0.0.1`, port `3306` (or your configured port), username, and password.

8. **Verify actual MySQL table contents** using Workbench or the MySQL CLI:

```sql
USE university_search;
SHOW TABLES;
SELECT id,title,status,original_filename,created_at FROM documents ORDER BY id DESC LIMIT 20;
SELECT id,state,attempts,last_error FROM processing_jobs ORDER BY id DESC LIMIT 20;
SELECT COUNT(*) AS terms FROM terms;
SELECT COUNT(*) AS postings FROM postings;
```

These queries return empty/zero values until real uploads. That is intentional.

## Usage

1. Register/login through the React UI. Admins and faculty can be provisioned by the admin CLI; new web registrations are students.
2. Select **Upload & Index**. Choose **1–10** real PDF/DOCX/PPTX/TXT files, 10 MB per file by default. Add subject, semester, category, access level, and optional department.
3. Each accepted file is hashed with SHA-256 and gets exactly one durable job. The parent assigns up to three jobs to the three IPC child workers. Other documents wait in MySQL.
4. Engine 1 validates/extracts and (if needed) performs scanned-PDF OCR. Engine 2 creates positional tokens. Engine 3 commits terms, postings, document content and `INDEXED` status together in InnoDB.
5. Search using `machine AND learning`, `"machine learning"`, `network OR security`, `(database OR algorithm) AND NOT obsolete`. Results are from indexed, authorized document records only. The ranking score is calculated from actual postings; it is not mock data.
6. In the library, preview PDF or download supported source, edit metadata, replace file, delete your document. Admins can monitor jobs/failures and retry them. Files that failed preflight are rejected; files that fail during processing enter `FAILED` and appear in the admin error list.
7. Restart the API and repeat the search: data stays in MySQL; you do **not** reindex everything on startup.

**Security note:** student-uploaded documents default to `UNIVERSITY` access, not `PUBLIC`. Authorization is checked before search candidates are retrieved and again before viewing/downloading. Public access is still behind login in this starter. Only owners or admins may edit/delete/replace. For genuine production deployment add TLS, centralized monitoring, backups, storage hardening, and a stronger token/session architecture.

## Tests and verification

```bash
# From the project root; tests do not seed production data
bash scripts/check.sh

# E1 extraction tests require installing the E1 dependencies above
cd engines/engine-1-document-processing && npm test

# Additional DB integration checks require an actual MySQL 8.0+ instance
# and configured credentials; review docs/TESTING.md.
```

`npm run migrate` and a live React build **could not be verified here without an installed MySQL service and npm dependencies**. Tests are documented as verified only if they actually ran; see `docs/TESTING.md`.

## Configuration reference

- `MAX_UPLOAD_FILES=10`, `MAX_FILE_MB=10`
- `OCR_ENABLED=true`, `OCR_MAX_PAGES=5` (Poppler + Tesseract tools required)
- `PROCESS_TIMEOUT_MS=90000` (worker killed/restarted after timeout)
- Worker count is **fixed at three**, not configurable, to meet your specification
- API `5001`, Vite `5173` and `FRONTEND_ORIGIN` must agree

## Folder map

```
engines/
  engine-1-document-processing/     # Node fork worker and format extraction
  engine-2-search-retrieval/         # Boolean, phrase, TF-IDF Top-K
  engine-3-persistent-index/         # MySQL schema and transactional repository
  engine-4-search-control-interface/
    backend/                         # REST, auth, worker parent, MySQL pool
    frontend/                        # React/Vite web UI, real API calls
scripts/                              # checks and real benchmark commands
docs/                                 # architecture, API, testing, security
```

**Limits to disclose at review:** legacy `.doc` and `.ppt` are not supported in this edition (the pasted spec's supported format list is PDF/DOCX/PPTX/TXT). OCR is specific to image-based PDFs and is limited to the first configured number of pages; no automatic OCR of embedded images in DOCX/PPTX. Only one backend parent instance is supported for its three-worker restart recovery. Some advanced production concerns require more work and real-environment tests.
