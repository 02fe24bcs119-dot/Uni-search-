import { extname } from 'node:path'
export const MIME = Object.freeze({
  '.pdf':'application/pdf', '.docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.pptx':'application/vnd.openxmlformats-officedocument.presentationml.presentation', '.txt':'text/plain',
})
export function safeFilename(name) {
  return String(name || '').replaceAll('\\','/').split('/').at(-1).replace(/[\x00-\x1f\x7f"<>]/g,'_').slice(0,200)
}
export function isSupported(name) { return Object.hasOwn(MIME,extname(safeFilename(name)).toLowerCase()) }
/** Content-based preflight, not extension-only validation. */
export async function validateBuffer(name, data) {
  const ext = extname(safeFilename(name)).toLowerCase()
  if (!MIME[ext]) throw Object.assign(new Error('Only PDF, DOCX, PPTX and TXT are accepted'),{code:'INVALID_FILE'})
  if (!Buffer.isBuffer(data) || data.length < 1) throw Object.assign(new Error('Empty document'),{code:'INVALID_FILE'})
  if (ext === '.pdf') {
    if (data.subarray(0,5).toString() !== '%PDF-' || !data.subarray(-4096).includes(Buffer.from('%%EOF'))) throw new Error('Corrupted PDF structure')
    const {default:pdfParse}=await import('pdf-parse')
    try { await pdfParse(data) } catch { throw new Error('Unreadable or corrupted PDF') }
  } else if (ext === '.docx' || ext === '.pptx') {
    if (data.subarray(0,2).toString() !== 'PK') throw new Error('Invalid Office document structure')
    const {default:JSZip}=await import('jszip')
    let archive
    try { archive = await JSZip.loadAsync(data,{checkCRC32:true}) } catch { throw new Error('Corrupt Office ZIP archive') }
    const unpacked=Object.values(archive.files).reduce((size,file)=>size+(file._data?.uncompressedSize||0),0)
    if (unpacked>60*1024*1024)throw new Error('Office archive expands beyond size limit')
    if (!archive.file('[Content_Types].xml') || !archive.file(ext === '.docx'?'word/document.xml':'ppt/presentation.xml')) throw new Error('File content does not match extension')
  } else {
    if (data.includes(0)) throw new Error('TXT contains binary data')
    try { new TextDecoder('utf-8',{fatal:true}).decode(data) } catch { throw new Error('TXT must be UTF-8 text') }
  }
  return {extension:ext,mimeType:MIME[ext]}
}
