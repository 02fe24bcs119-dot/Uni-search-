/** Engine 1 token positions match Engine 2's Unicode-safe query tokenization. */
export function tokenize(text) { return String(text).normalize('NFKC').toLowerCase().match(/[\p{L}\p{N}]+/gu) ?? [] }
export const STOP_WORDS = new Set(['a','an','the','and','or','of','to','in','on','at','is','it','for','by','as','be','are','was','were','with'])
export function indexText(text) {
  if (typeof text !== 'string' || text.length > 2_000_000) throw new Error('Extracted text invalid or exceeds 2 MB')
  const tokens = tokenize(text)
  if (tokens.length > 200_000) throw new Error('Document exceeds token limit')
  const terms = Object.create(null)
  for (let i = 0; i < tokens.length; i++) {
    const term = tokens[i]
    if (term.length > 191) continue
    ;(terms[term] ??= []).push(i)
  }
  if (Object.keys(terms).length > 75_000) throw new Error('Too many unique terms')
  // Stopwords are retained in positions so exact phrase queries still work.
  // Engine 2 excludes stopwords from weighted TF-IDF scoring for ordinary searches.
  return { terms, document_length: tokens.length, extracted_text: text.slice(0, 2_000_000) }
}
