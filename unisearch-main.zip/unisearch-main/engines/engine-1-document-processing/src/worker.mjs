import { extractDocument } from './extract.mjs'
import { createDocumentContract } from './documentContract.mjs'
if (!process.send) throw new Error('Engine 1 worker must run via Node.js fork() IPC')
let busy=false
process.on('message',async message=>{
  if(message?.type==='SHUTDOWN'){if(!busy)process.exit(0);else process.once('idle',()=>process.exit(0));return}
  if(message?.type!=='PROCESS')return
  if(busy){process.send({type:'ERROR',jobId:message.jobId,error:'Worker received overlapping jobs',retryable:true});return}
  busy=true
  try {
    const extracted=await extractDocument(message.path,{...message.options,onStage:(stage)=>process.send({type:'STAGE',jobId:message.jobId,stage})})
    const result=createDocumentContract(message.document,extracted)
    process.send({type:'RESULT',jobId:message.jobId,result})
  } catch(error){ process.send({type:'ERROR',jobId:message.jobId,error:String(error.message).slice(0,450),retryable:Boolean(error.retryable)}) }
  finally {busy=false;process.emit('idle')}
})
process.send({type:'READY',pid:process.pid})
