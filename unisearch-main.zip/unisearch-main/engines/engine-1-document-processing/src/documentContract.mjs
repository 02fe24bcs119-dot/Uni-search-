/** Cross-engine, validated processing contract. No mock metadata. */
export function createDocumentContract(document, processed) {
 if(!document || !processed)throw new Error('Missing document contract fields')
 const id=Number(document.document_id)
 if(!Number.isSafeInteger(id)||id<1)throw new Error('Invalid document ID in contract')
 if(typeof document.file_sha256!=='string'||!/^[a-f0-9]{64}$/.test(document.file_sha256))throw new Error('Invalid document SHA-256')
 if(document.file_sha256!==processed.file_sha256)throw new Error('Source document changed after upload; SHA-256 mismatch')
 if(Number(document.file_size_bytes)!==processed.source_bytes)throw new Error('Source document size changed after upload')
 if(typeof processed.extracted_text!=='string'||processed.document_length<1||!processed.terms||!Object.keys(processed.terms).length)throw new Error('No indexable text in processing contract')
 return {
  documentId:id,
  fileName:document.original_filename,
  fileType:processed.extension.slice(1).toUpperCase(),
  mimeType:document.mime_type,
  fileSize:Number(document.file_size_bytes),
  fileHash:document.file_sha256,
  extractedText:processed.extracted_text,
  metadata:{subject:document.subject||null,semester:document.semester||null,category:document.category||null,accessLevel:document.access_level},
  processingStatus:'EXTRACTED',
  extractionMethod:processed.extraction_method,
  createdAt:document.created_at,
  updatedAt:new Date().toISOString(),
  error:null,
  terms:processed.terms,
  document_length:processed.document_length,
  extracted_text:processed.extracted_text,
 }
}
export function validateDocumentContract(contract,expectedDocumentId){
 if(!contract||Number(contract.documentId)!==Number(expectedDocumentId)||contract.processingStatus!=='EXTRACTED'||
 !/^[a-f0-9]{64}$/.test(contract.fileHash??'')||typeof contract.extractedText!=='string'||
 typeof contract.terms!=='object'||!Number.isSafeInteger(contract.document_length)||contract.document_length<1)
 throw new Error('Malformed cross-engine processing contract')
 return contract
}
