import { createHash } from 'node:crypto'
import { readFile, mkdtemp, readdir, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, extname } from 'node:path'
import { spawn } from 'node:child_process'
import { indexText } from './textNormalizer.mjs'
import { validateBuffer } from './fileValidator.mjs'
const decodeEntities = (text) => text.replace(/&(?:amp|lt|gt|quot|apos|#\d+|#x[0-9a-f]+);/gi, (entity) => {
  const map = { '&amp;':'&', '&lt;':'<','&gt;':'>','&quot;':'"','&apos;':"'" }
  if (map[entity]) return map[entity]
  if (entity.startsWith('&#')) return String.fromCodePoint(parseInt(entity.slice(entity[2].toLowerCase()==='x'?3:2,-1),entity[2].toLowerCase()==='x'?16:10) || 32)
  return entity
})
const xmlParagraphs = (xml) => {
  // PPTX slide XML stores text as <a:t> spans grouped in paragraphs.
  return [...xml.matchAll(/<a:p(?:\s[^>]*)?>([\s\S]*?)<\/a:p>/g)]
    .map((m)=>[...m[1].matchAll(/<a:t(?:\s[^>]*)?>([\s\S]*?)<\/a:t>/g)]
      .map((t)=>decodeEntities(t[1])).join(' ')).filter(Boolean).join('\n')
}
function runCommand(command,args,timeoutMs=30000) {
  return new Promise((resolve,reject)=>{
    const proc=spawn(command,args,{stdio:['ignore','pipe','pipe']})
    let output='',err='',done=false
    const timer=setTimeout(()=>{proc.kill('SIGKILL');finish(new Error(`${command} timed out`))},timeoutMs)
    function finish(error,result) { if(done)return;done=true;clearTimeout(timer);error?reject(error):resolve(result) }
    proc.stdout.on('data',buf=>{output+=buf.toString();if(output.length>2_000_000){proc.kill('SIGKILL');finish(new Error('OCR output too large'))}})
    proc.stderr.on('data',buf=>{err=(err+buf.toString()).slice(-1500)})
    proc.on('error',()=>finish(new Error(`Required OCR tool '${command}' is unavailable; install Tesseract and Poppler`)))
    proc.on('close',code=> code===0?finish(null,output):finish(new Error(`${command} failed: ${err.slice(-250)}`)))
  })
}
async function ocrPdf(path, maxPages) {
  const dir=await mkdtemp(join(tmpdir(),'unidoc-ocr-'))
  try {
    await runCommand('pdftoppm',['-f','1','-l',String(maxPages),'-r','120','-png',path,join(dir,'page')],60000)
    const images=(await readdir(dir)).filter(name=>name.endsWith('.png')).sort()
    if(!images.length) throw new Error('No PDF pages rendered for OCR')
    let result=''
    for(const name of images) result+=(await runCommand('tesseract',[join(dir,name),'stdout','-l','eng'],40000))+'\n'
    return result
  } finally { await rm(dir,{recursive:true,force:true}) }
}
export async function extractDocument(filePath,{ocrEnabled=true,ocrMaxPages=5,onStage=()=>{}}={}) {
  const buffer=await readFile(filePath)
  const {extension}=await validateBuffer(filePath,buffer)
  let text='',method='native'
  if(extension==='.pdf') {
    const {default:pdfParse}=await import('pdf-parse')
    const pdf=await pdfParse(buffer)
    text=pdf.text || ''
    if(text.trim().length<20 && ocrEnabled) {
      onStage('OCR_PROCESSING')
      text=await ocrPdf(filePath,ocrMaxPages)
      method='tesseract'
    }
  } else if(extension==='.docx') {
    const {default:mammoth}=await import('mammoth')
    text=(await mammoth.extractRawText({buffer})).value
  } else if(extension==='.pptx') {
    const {default:JSZip}=await import('jszip')
    const zip=await JSZip.loadAsync(buffer)
    const pages=Object.keys(zip.files).filter(key=>/^ppt\/slides\/slide\d+\.xml$/.test(key))
      .sort((a,b)=>Number(a.match(/slide(\d+)/)[1])-Number(b.match(/slide(\d+)/)[1]))
    for(const page of pages) text+=xmlParagraphs(await zip.file(page).async('string'))+'\n'
  } else text=new TextDecoder('utf-8',{fatal:true}).decode(buffer)
  const result=indexText(text)
  if(result.document_length===0) throw Object.assign(new Error('Document contains no readable text; OCR may be required'),{retryable:false})
  return {...result,extraction_method:method,extension,source_bytes:buffer.length,file_sha256:createHash('sha256').update(buffer).digest('hex')}
}
