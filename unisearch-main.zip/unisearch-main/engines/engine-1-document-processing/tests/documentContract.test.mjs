import {test} from 'node:test'
import assert from 'node:assert/strict'
import {createDocumentContract,validateDocumentContract} from '../src/documentContract.mjs'
test('contract carries verified source metadata and exact positional tokens',()=>{
 const fileHash='a'.repeat(64)
 const actual={document_id:1,original_filename:'paper.txt',mime_type:'text/plain',file_size_bytes:11,file_sha256:fileHash,access_level:'UNIVERSITY'}
 const extracted={file_sha256:fileHash,source_bytes:11,document_length:2,extracted_text:'hello world',terms:{hello:[0],world:[1]},extension:'.txt',extraction_method:'native'}
 const contract=createDocumentContract(actual,extracted)
 assert.equal(contract.documentId,1);assert.equal(contract.fileHash,fileHash);assert.equal(contract.terms.hello[0],0)
 assert.equal(validateDocumentContract(contract,1),contract)
})
test('changed original file is rejected from the cross-engine contract',()=>{
 assert.throws(()=>createDocumentContract({document_id:1,file_sha256:'a'.repeat(64),file_size_bytes:2},{file_sha256:'b'.repeat(64),source_bytes:2}),/changed/)
})
