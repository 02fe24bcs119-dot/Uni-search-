import test from 'node:test'
import assert from 'node:assert/strict'
import {indexText,tokenize} from '../src/textNormalizer.mjs'
test('tokenization is case insensitive and Unicode-normalized',()=>assert.deepEqual(tokenize('MACHINE learning machine'),['machine','learning','machine']))
test('index holds positions and frequencies without losing phrase stopwords',()=>{
 const index=indexText('Machine learning and machine learning')
 assert.deepEqual(index.terms.machine,[0,3]);assert.deepEqual(index.terms.and,[2]);assert.equal(index.document_length,5)
})
test('rejects huge text',()=>assert.throws(()=>indexText('x'.repeat(2000001)),/exceeds/))
