import test from 'node:test'
import assert from 'node:assert/strict'
import {fork} from 'node:child_process'
import {randomUUID,createHash} from 'node:crypto'
import {writeFile,mkdtemp,rm} from 'node:fs/promises'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {fileURLToPath} from 'node:url'
const worker=fileURLToPath(new URL('../src/worker.mjs',import.meta.url))
test('exactly three independent OS child workers process real text files over IPC',async()=>{
 const folder=await mkdtemp(join(tmpdir(),'unidoc-test-'))
 const children=[]
 try {
  const docs=await Promise.all(Array.from({length:5},async(_,i)=>{
   const text=`Document ${i} machine learning and indexing. `
   const path=join(folder,`${randomUUID()}.txt`)
   await writeFile(path,text)
   return {id:i+1,path,text}
  }))
  const queue=[...docs],results=[]
  const all=await Promise.all(Array.from({length:3},async(_,i)=>new Promise((resolve,reject)=>{
   const child=fork(worker,[],{stdio:['ignore','ignore','inherit','ipc']})
   children.push(child);assert.notEqual(child.pid,process.pid)
   let active=null
   let timeout=setTimeout(()=>{child.kill('SIGKILL');reject(new Error('Child worker timeout'))},15000)
   const assign=()=>{
    if(active)return
    const doc=queue.shift()
    if(!doc){clearTimeout(timeout);child.send({type:'SHUTDOWN'});resolve();return}
    active=doc
    child.send({type:'PROCESS',jobId:doc.id,path:doc.path,document:{document_id:doc.id,file_sha256:createHash('sha256').update(doc.text).digest('hex'),file_size_bytes:Buffer.byteLength(doc.text),original_filename:'test.txt',mime_type:'text/plain',access_level:'UNIVERSITY'},options:{ocrEnabled:false}})
   }
   child.on('message',msg=>{
    if(msg.type==='READY'){assign();return}
    if(msg.type==='RESULT'){assert.equal(msg.jobId,active.id);assert.ok(msg.result.terms.machine?.length);results.push(msg.result);active=null;assign()}
    if(msg.type==='ERROR')reject(new Error(msg.error))
   })
   child.on('error',reject)
  })))
  assert.equal(children.length,3)
  assert.equal(new Set(children.map(c=>c.pid)).size,3)
  assert.equal(results.length,5)
  assert.ok(all.every(x=>x===undefined))
 }finally{
  for(const child of children){if(!child.killed)child.kill('SIGTERM')}
  await rm(folder,{recursive:true,force:true})
 }
},{timeout:20000})
