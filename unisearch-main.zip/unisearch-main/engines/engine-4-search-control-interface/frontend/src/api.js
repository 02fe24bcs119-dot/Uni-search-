const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:5001'

export async function api(path, token, options = {}) {
  const { body, headers: extraHeaders, ...rest } = options
  const headers = { ...extraHeaders }
  if (token) headers.Authorization = `Bearer ${token}`
  if (body && !(body instanceof FormData)) headers['Content-Type'] = 'application/json'
  let response
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...rest,
      headers,
      body: body instanceof FormData ? body : body === undefined ? undefined : JSON.stringify(body),
    })
  } catch {
    throw new Error('Cannot reach the backend. Check that Engine 4 is running on port 5001.')
  }
  if (!response.ok) {
    const error = await response.json().catch(() => ({}))
    const e = new Error(error.message || `HTTP ${response.status}`)
    e.status = response.status
    throw e
  }
  if (options.responseType === 'blob') return response.blob()
  return response.json()
}

export async function documentBlob(id, token, action) {
  const response = await fetch(`${API_BASE}/api/documents/${encodeURIComponent(id)}/${action}`, {
    headers: { Authorization: `Bearer ${token}` },
  })
  if (!response.ok) {
    const error = await response.json().catch(() => ({}))
    const e = new Error(error.message || `HTTP ${response.status}`)
    e.status = response.status
    throw e
  }
  return response.blob()
}

/** Authenticated SSE: fetch supports bearer headers, EventSource does not. */
export function listenToStatuses(token, callback) {
  const controller = new AbortController()
  const decoder = new TextDecoder()
  let reconnectTimer = null
  async function connect() {
    try {
      const response = await fetch(`${API_BASE}/api/events`, {
        headers: { Authorization: `Bearer ${token}` },
        signal: controller.signal,
      })
      if (!response.ok || !response.body) return
      const reader = response.body.getReader()
      let buffer = ''
      while (!controller.signal.aborted) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true }).replaceAll('\r', '')
        let boundary
        while ((boundary = buffer.indexOf('\n\n')) >= 0) {
          const event = buffer.slice(0, boundary)
          buffer = buffer.slice(boundary + 2)
          if (event.includes('event: statuses')) {
            const data = event.split('\n').find((line) => line.startsWith('data: '))
            if (data) callback(JSON.parse(data.slice(6)))
          }
        }
      }
    } catch (error) {
      if (!controller.signal.aborted) console.warn('Live updates interrupted; reconnecting.', error)
    } finally {
      if (!controller.signal.aborted) reconnectTimer = setTimeout(connect, 5000)
    }
  }
  void connect()
  return () => { controller.abort(); clearTimeout(reconnectTimer) }
}

/** XHR gives actual bytes-sent progress; no simulated percentages. */
export function uploadDocuments(token, formData, onProgress) {
  return new Promise((resolve,reject)=>{
    const xhr=new XMLHttpRequest()
    xhr.open('POST',`${API_BASE}/api/documents/upload`)
    xhr.setRequestHeader('Authorization',`Bearer ${token}`)
    xhr.upload.onprogress=event=>{if(event.lengthComputable)onProgress(Math.round(event.loaded/event.total*100))}
    xhr.onload=()=>{
      let payload
      try{payload=JSON.parse(xhr.responseText)}catch{payload={message:'Invalid server response'}}
      if(xhr.status>=200&&xhr.status<300)resolve(payload)
      else {const error=new Error(payload.message||`HTTP ${xhr.status}`);error.status=xhr.status;reject(error)}
    }
    xhr.onerror=()=>reject(new Error('Network interrupted during upload'))
    xhr.send(formData)
  })
}
