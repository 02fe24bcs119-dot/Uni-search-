import { createHash,randomUUID } from 'node:crypto'
import { basename,extname,join } from 'node:path'
import { mkdir,writeFile,unlink } from 'node:fs/promises'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import multer from 'multer'
import {rateLimit} from 'express-rate-limit'
import {pool} from './database.mjs'
import {config} from './config.mjs'
import {authRouter,requireAuth} from './auth.mjs'
import {createWorkerManager} from './workerManager.mjs'
import {parseQuery,searchIndex,makeSnippet,STOP_WORDS} from '../../../engine-2-search-retrieval/src/search.mjs'
import {MIME,safeFilename,validateBuffer} from '../../../engine-1-document-processing/src/fileValidator.mjs'
import {
 validId,listDocuments,getDocument,getPostings,getSnippets,searchCandidates,insertDocumentAndJob,
 audit,stats,listJobs,listFailures,listAudit,updateMetadata,replaceFile,deleteDocument,requeue,
} from '../../../engine-3-persistent-index/src/repository.mjs'

const app=express()
app.disable('x-powered-by')
app.use(helmet({crossOriginResourcePolicy:{policy:'cross-origin'}}))
app.use(cors({origin:config.frontendOrigin}))
app.use(rateLimit({windowMs:15*60*1000,limit:500,standardHeaders:'draft-8',legacyHeaders:false}))
app.use(express.json({limit:'64kb'}))
app.use('/api/auth',authRouter)
const manager=createWorkerManager(pool)
const recentSearchMs=[]
const recordSearchMs=ms=>{recentSearchMs.push(ms);if(recentSearchMs.length>100)recentSearchMs.shift()}
const currentSearchMetrics=()=>{if(!recentSearchMs.length)return{samples:0,last_ms:null,mean_ms:null,p95_ms:null};const sorted=[...recentSearchMs].sort((a,b)=>a-b);return{samples:recentSearchMs.length,last_ms:recentSearchMs.at(-1),mean_ms:recentSearchMs.reduce((a,b)=>a+b,0)/recentSearchMs.length,p95_ms:sorted[Math.ceil(sorted.length*.95)-1]}}
const ACCESS=['PUBLIC','UNIVERSITY','DEPARTMENT','RESTRICTED','PRIVATE']
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:config.maxFileMb*1024*1024,files:config.maxUploadFiles,fields:15,parts:config.maxUploadFiles+15}})
const receive=upload.fields([{name:'documents',maxCount:config.maxUploadFiles},{name:'document',maxCount:1}])
const respondError=(res,code,message)=>res.status(code).json({success:false,message})
const isAdmin=req=>req.user.role==='ADMIN'
function requireAdmin(req,res,next){if(!isAdmin(req))return respondError(res,403,'Administrator role required');next()}
function mayEdit(user,doc){return user.role==='ADMIN'||String(doc.uploaded_by)===String(user.id)}
function validText(value,max,required=false){return typeof value==='string'&&value.length<=max&&(!required||value.trim().length>0)}
function nullable(value,max){return value==null||value===''?null:typeof value==='string'&&value.length<=max?value.trim():undefined}
function metadataFrom(body,user,{single=false,fileName=''}={}){
 const title=single&&typeof body.title==='string'&&body.title.trim()?body.title.trim():fileName.replace(/\.[^.]+$/,'').slice(0,200)
 const description=body.description??''
 const subject=nullable(body.subject,100),semester=nullable(body.semester,30),category=nullable(body.category,80)
 const accessLevel=String(body.accessLevel||'UNIVERSITY').toUpperCase()
 const departmentId=body.departmentId===''||body.departmentId==null?(user.department_id??null):Number(body.departmentId)
 if(!title||title.length>200||!validText(description,2000)||[subject,semester,category].some(x=>x===undefined))throw Object.assign(new Error('Invalid title, description, subject, semester or category'),{status:400})
 if(!ACCESS.includes(accessLevel))throw Object.assign(new Error('Invalid access level'),{status:400})
 if(departmentId!==null&&!validId(departmentId))throw Object.assign(new Error('Invalid department ID'),{status:400})
 if(accessLevel==='DEPARTMENT'&&departmentId===null)throw Object.assign(new Error('Department documents require a department'),{status:400})
 if(user.role!=='ADMIN'&&departmentId!==null&&String(user.department_id)!==String(departmentId))throw Object.assign(new Error('Cannot assign another department'),{status:403})
 return {title,description,subject,semester,category,accessLevel,departmentId}
}
function validateId(req,res){if(!validId(req.params.id)){respondError(res,400,'Invalid document ID');return null}return Number(req.params.id)}
async function ownedDoc(req,res){const id=validateId(req,res);if(!id)return null;const doc=await getDocument(pool,req.user,id);if(!doc){respondError(res,404,'Document not found');return null}if(!mayEdit(req.user,doc)){respondError(res,403,'Only uploader or admin may modify document');return null}return doc}
const cleanStoredName=name=>typeof name==='string'&&/^[0-9a-f-]{36}\.(pdf|docx|pptx|txt)$/.test(name)

app.get('/api/health',async(req,res)=>{
 try{await pool.query('SELECT 1');res.json({success:true,status:'ok',database:'mysql',engine1:'node-child-process-ipc',engine2:'positional-tfidf',engine3:'mysql-innodb',engine4:'express'})}
 catch{res.status(503).json({success:false,status:'unavailable',message:'MySQL connection unavailable'})}
})
app.get('/api/departments',requireAuth,async(req,res,next)=>{try{const [rows]=await pool.query('SELECT id,name FROM departments ORDER BY name');res.json({success:true,departments:rows})}catch(e){next(e)}})
app.post('/api/departments',requireAuth,requireAdmin,async(req,res,next)=>{
 try{if(!validText(req.body?.name,120,true))return respondError(res,400,'Invalid department name');const [r]=await pool.execute('INSERT INTO departments(name) VALUES(?)',[req.body.name.trim()]);res.status(201).json({success:true,id:r.insertId})}catch(e){next(e)}
})
app.get('/api/documents',requireAuth,async(req,res,next)=>{
 try {const documents=await listDocuments(pool,req.user,{limit:req.query.limit,offset:req.query.offset});res.json({success:true,count:documents.length,documents})}catch(e){next(e)}
})
app.post('/api/documents/upload',requireAuth,receive,async(req,res,next)=>{
 try {
  const files=[...(req.files?.documents||[]),...(req.files?.document||[])]
  if(!files.length||files.length>config.maxUploadFiles)return respondError(res,400,`Select 1–${config.maxUploadFiles} files`)
  const candidates=[];const hashes=new Set()
  // Reject the entire request before writing if any file is invalid.
  for(const file of files){
   const name=safeFilename(file.originalname)
   const ext=extname(name).toLowerCase()
   let mimeType
   try{({mimeType}=await validateBuffer(name,file.buffer))}catch(e){throw Object.assign(e,{status:400})}
   const metadata=metadataFrom(req.body,req.user,{single:files.length===1,fileName:name})
   const sha256=createHash('sha256').update(file.buffer).digest('hex')
   if(hashes.has(sha256))return respondError(res,409,'The same file was selected more than once')
   hashes.add(sha256)
   candidates.push({...metadata,originalFilename:name,mimeType,size:file.size,sha256,ext,buffer:file.buffer})
  }
  const results=[]
  for(const item of candidates){
   const storedFilename=randomUUID()+item.ext
   const path=join(config.uploadDir,storedFilename)
   try {
    // SHA duplicates across sessions are guarded by a UNIQUE constraint.
    const [existing]=await pool.execute('SELECT id FROM documents WHERE file_sha256=? LIMIT 1',[item.sha256])
    if(existing.length){results.push({filename:item.originalFilename,status:'DUPLICATE',message:'Identical file already indexed or queued'});continue}
    await writeFile(path,item.buffer,{flag:'wx',mode:0o600})
    const document=await insertDocumentAndJob(pool,{...item,storedFilename},req.user)
    results.push({filename:item.originalFilename,status:'QUEUED',documentId:document.id})
   }catch(error){await unlink(path).catch(()=>{})
    if(error.code==='ER_DUP_ENTRY')results.push({filename:item.originalFilename,status:'DUPLICATE',message:'File already uploaded'})
    else if(error.code==='ER_NO_REFERENCED_ROW_2')results.push({filename:item.originalFilename,status:'ERROR',message:'Department does not exist'})
    else{console.error('Upload failed:',error.message);results.push({filename:item.originalFilename,status:'ERROR',message:'Upload failed; consult server logs'})}
   }
  }
  manager.wake()
  const accepted=results.filter(x=>x.status==='QUEUED').length
  res.status(accepted===results.length?202:accepted?207:results.every(x=>x.status==='DUPLICATE')?409:400)
   .json({success:accepted>0,accepted,count:results.length,results,message:`${accepted} document(s) queued`,processing:'asynchronous'})
 }catch(error){if(error.status)return respondError(res,error.status,error.message);next(error)}
})
app.get('/api/documents/:id',requireAuth,async(req,res,next)=>{
 try{const id=validateId(req,res);if(!id)return;const doc=await getDocument(pool,req.user,id);if(!doc)return respondError(res,404,'Document not found');const {stored_filename,...safe}=doc;res.json({success:true,document:safe})}catch(e){next(e)}
})
app.get('/api/documents/:id/status',requireAuth,async(req,res,next)=>{
 try{const id=validateId(req,res);if(!id)return;const doc=await getDocument(pool,req.user,id);if(!doc)return respondError(res,404,'Document not found');res.json({success:true,id,status:doc.status,error:doc.status==='FAILED'?doc.processing_error:null})}catch(e){next(e)}
})
async function serveFile(req,res,next,download){
 try{
  const id=validateId(req,res);if(!id)return
  const doc=await getDocument(pool,req.user,id)
  if(!doc)return respondError(res,404,'Document not found')
  if(!cleanStoredName(doc.stored_filename))return respondError(res,500,'Invalid storage path')
  const suffix=extname(doc.stored_filename).toLowerCase()
  const inline=!download&&suffix==='.pdf'
  res.set({'Content-Type':MIME[suffix],'X-Content-Type-Options':'nosniff','Content-Disposition':`${inline?'inline':'attachment'}; filename="document-${doc.id}${suffix}"`})
  res.sendFile(basename(doc.stored_filename),{root:config.uploadDir},e=>{if(e&&!res.headersSent)next(e)})
 }catch(error){next(error)}
}
app.get('/api/documents/:id/preview',requireAuth,(req,res,next)=>serveFile(req,res,next,false))
app.get('/api/documents/:id/download',requireAuth,(req,res,next)=>serveFile(req,res,next,true))
app.patch('/api/documents/:id',requireAuth,async(req,res,next)=>{
 try {const doc=await ownedDoc(req,res);if(!doc)return
  const body={...doc,...req.body}
  const meta=metadataFrom({title:body.title,description:body.description,subject:body.subject,semester:body.semester,category:body.category,accessLevel:req.body.accessLevel??body.access_level,departmentId:Object.hasOwn(req.body,'departmentId')?req.body.departmentId:body.department_id},req.user,{single:true,fileName:body.original_filename})
  await updateMetadata(pool,doc.id,meta,req.user);res.json({success:true,message:'Document metadata updated'})
 }catch(e){if(e.status)return respondError(res,e.status,e.message);next(e)}
})
app.put('/api/documents/:id/file',requireAuth,upload.single('document'),async(req,res,next)=>{
 let path=null,committed=false
 try{
  const doc=await ownedDoc(req,res);if(!doc)return
  if(!req.file)return respondError(res,400,'Replacement file required')
  const name=safeFilename(req.file.originalname)
  let mimeType,extension
  try{({mimeType,extension}=await validateBuffer(name,req.file.buffer))}catch(e){throw Object.assign(e,{status:400})}
  const sha256=createHash('sha256').update(req.file.buffer).digest('hex')
  if(sha256===doc.file_sha256)return respondError(res,409,'File content unchanged')
  const storedFilename=randomUUID()+extension
  path=join(config.uploadDir,storedFilename)
  await writeFile(path,req.file.buffer,{flag:'wx',mode:0o600})
  const result=await replaceFile(pool,doc.id,{originalFilename:name,storedFilename,mimeType,size:req.file.size,sha256},req.user)
  if(result.state!=='queued')return respondError(res,result.state==='duplicate'||result.state==='busy'?409:404,`Cannot replace: ${result.state}`)
  committed=true
  await unlink(join(config.uploadDir,result.oldFilename)).catch(e=>console.error('Old file cleanup:',e.message))
  manager.wake();res.status(202).json({success:true,id:doc.id,status:'QUEUED'})
 }catch(e){if(e.status)return respondError(res,e.status,e.message);if(e.code==='ER_DUP_ENTRY')return respondError(res,409,'Duplicate content');next(e)}
 finally{if(path&&!committed)await unlink(path).catch(()=>{})}
})
app.delete('/api/documents/:id',requireAuth,async(req,res,next)=>{
 try{const doc=await ownedDoc(req,res);if(!doc)return
  const result=await deleteDocument(pool,doc.id,req.user)
  if(result.state!=='deleted')return respondError(res,result.state==='busy'?409:404,`Cannot delete: ${result.state}`)
  if(cleanStoredName(result.storedFilename))await unlink(join(config.uploadDir,result.storedFilename)).catch(e=>console.error('File cleanup:',e.message))
  res.json({success:true,message:'Document and index records deleted'})
 }catch(e){next(e)}
})
app.post('/api/documents/:id/retry',requireAuth,async(req,res,next)=>{
 try{const doc=await ownedDoc(req,res);if(!doc)return
  const result=await requeue(pool,doc.id)
  if(result!=='queued')return respondError(res,409,`Cannot queue: ${result}`)
  await audit(pool,{actorId:req.user.id,actorEmail:req.user.email,action:'RETRY',outcome:'SUCCESS',documentId:doc.id})
  manager.wake();res.status(202).json({success:true,id:doc.id,status:'QUEUED'})
 }catch(e){next(e)}
})
app.get('/api/search',requireAuth,async(req,res,next)=>{
 try{
  if(typeof req.query.q!=='string'||!req.query.q.trim())return respondError(res,400,'Enter a search query')
  const started=performance.now()
  let parsed
  try{parsed=parseQuery(req.query.q)}catch(e){return respondError(res,400,e.message)}
  if(parsed.terms.length>20)return respondError(res,400,'Maximum 20 query terms')
  if(parsed.terms.every(t=>STOP_WORDS.has(t))&&!parsed.postfix.some(node=>node.type==='PHRASE'))return respondError(res,400,'Query contains only stop words; add a meaningful term or use an exact phrase')
  const offset=Math.max(0,Math.min(1000,Number(req.query.offset)||0))
  const limit=Math.max(1,Math.min(50,Number(req.query.limit)||10))
  const filters={}
  for(const key of ['subject','semester','category'])if(typeof req.query[key]==='string'&&req.query[key].length<=100)filters[key]=req.query[key]
  if(typeof req.query.fileType==='string'&&Object.hasOwn(MIME,'.'+req.query.fileType.toLowerCase()))filters.fileType=MIME['.'+req.query.fileType.toLowerCase()]
  if(validId(req.query.departmentId))filters.departmentId=req.query.departmentId
  // Authorize BEFORE retrieving postings or text snippets. No protected title, text, score or ID leaks.
  const {documents:docs,total}=await searchCandidates(pool,req.user,parsed.terms,filters,parsed.postfix.some(n=>n.type==='OP'&&n.value==='NOT'))
  const postings=await getPostings(pool,parsed.terms,docs.map(x=>x.id))
  const matched=searchIndex({query:req.query.q,documents:docs.map(d=>({...d,status:'READY'})),postings,limit,totalDocs:total,offset})
  const excerpts=await getSnippets(pool,matched.results.map(r=>r.id))
  const elapsed=Math.round((performance.now()-started)*100)/100
  recordSearchMs(elapsed)
  res.json({success:true,query:req.query.q,total:matched.count,count:matched.results.length,offset,limit,
   executionMs:elapsed,
   results:matched.results.map(d=>({...d,status:'INDEXED',snippet:makeSnippet(excerpts.get(String(d.id)),parsed.terms)}))})
 }catch(e){next(e)}
})
app.get('/api/workers',requireAuth,requireAdmin,(req,res)=>res.json({success:true,...manager.status()}))
app.get('/api/jobs',requireAuth,requireAdmin,async(req,res,next)=>{try{res.json({success:true,jobs:await listJobs(pool),failures:await listFailures(pool)})}catch(e){next(e)}})
app.get('/api/stats',requireAuth,requireAdmin,async(req,res,next)=>{try{res.json({success:true,...await stats(pool),workers:manager.status(),search_latency:currentSearchMetrics()})}catch(e){next(e)}})
app.get('/api/audit',requireAuth,requireAdmin,async(req,res,next)=>{try{res.json({success:true,events:await listAudit(pool)})}catch(e){next(e)}})
app.get('/api/events',requireAuth,(req,res)=>{
 res.set({'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive'})
 res.flushHeaders();res.write(': connected\n\n')
 let closed=false,busy=false
 async function tick(){if(closed||busy)return;busy=true
  try{
   const docs=await listDocuments(pool,req.user,{limit:500})
   if(!closed)res.write(`event: statuses\ndata: ${JSON.stringify(docs.map(d=>({id:d.id,status:d.status,error:d.status==='FAILED'?d.processing_error:null})))}\n\n`)
  }catch{if(!closed)res.write('event: error\ndata: {"message":"Status unavailable"}\n\n')}
  finally{busy=false}
 }
 void tick();const interval=setInterval(()=>{void tick()},3000),expiry=setTimeout(()=>res.end(),14*60*1000)
 res.on('close',()=>{closed=true;clearInterval(interval);clearTimeout(expiry)})
})
app.use((error,req,res,next)=>{
 console.error('API:',error.message)
 if(res.headersSent)return next(error)
 if(error instanceof multer.MulterError)return respondError(res,413,error.code==='LIMIT_FILE_SIZE'?'File exceeds size limit':`Upload rejected: ${error.code}`)
 if(error.code==='ER_DUP_ENTRY')return respondError(res,409,'Duplicate record')
 if(error.code==='ER_NO_REFERENCED_ROW_2')return respondError(res,400,'Unknown referenced record')
 if(error.message?.includes('Corrupt')||error.message?.includes('corrupt')||error.message?.includes('Invalid Office')||error.message?.includes('Unreadable')||error.message?.includes('TXT must')||error.message?.includes('TXT contains')||error.message?.includes('Only PDF'))return respondError(res,400,error.message)
 return respondError(res,500,'Server error; inspect backend logs')
})
await mkdir(config.uploadDir,{recursive:true})
await pool.query('SELECT 1')
await manager.start()
const server=app.listen(config.port,()=>console.log(`UniDoc MySQL API http://localhost:${config.port} | Engine 1 child workers: exactly 3`))
async function shutdown(){server.close();await manager.stop();await pool.end();process.exit(0)}
process.once('SIGTERM',()=>{void shutdown()});process.once('SIGINT',()=>{void shutdown()})
