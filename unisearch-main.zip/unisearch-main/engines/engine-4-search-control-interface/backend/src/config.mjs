import 'dotenv/config'
import { fileURLToPath } from 'node:url'
import { resolve } from 'node:path'
const intEnv = (name, fallback, lo, hi) => {
  const val = Number(process.env[name] || fallback)
  if (!Number.isSafeInteger(val) || val < lo || val > hi) throw new Error(`Invalid ${name}`)
  return val
}
export const config = {
  port: intEnv('PORT',5001,1,65535),
  frontendOrigin: process.env.FRONTEND_ORIGIN || 'http://localhost:5173',
  mysql: { host: process.env.MYSQL_HOST || '127.0.0.1', port: intEnv('MYSQL_PORT',3306,1,65535),
    user: process.env.MYSQL_USER || 'root', password: process.env.MYSQL_PASSWORD || '',
    database: process.env.MYSQL_DATABASE || 'university_search', waitForConnections: true,
    connectionLimit: 12, decimalNumbers: true, multipleStatements: false },
  jwtSecret: process.env.JWT_SECRET,
  maxUploadFiles: intEnv('MAX_UPLOAD_FILES',10,1,20),
  maxFileMb: intEnv('MAX_FILE_MB',10,1,30),
  processTimeoutMs: intEnv('PROCESS_TIMEOUT_MS',90000,10000,600000),
  uploadDir: resolve(fileURLToPath(new URL('../data/uploads/',import.meta.url))),
  workerFile: fileURLToPath(new URL('../../../engine-1-document-processing/src/worker.mjs',import.meta.url)),
  ocrEnabled: process.env.OCR_ENABLED !== 'false',
  ocrMaxPages: intEnv('OCR_MAX_PAGES',5,1,20),
  workerCount: 3,
}
if (!config.jwtSecret || config.jwtSecret.length < 32) throw new Error('JWT_SECRET must contain at least 32 characters')
