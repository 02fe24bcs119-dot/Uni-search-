import 'dotenv/config'
import argon2 from 'argon2'
import { pool } from './database.mjs'
const { ADMIN_EMAIL,ADMIN_PASSWORD,ADMIN_NAME }=process.env
if(!ADMIN_EMAIL||!ADMIN_PASSWORD||ADMIN_PASSWORD.length<12||!ADMIN_NAME) {
 console.error('Set ADMIN_EMAIL, ADMIN_NAME and ADMIN_PASSWORD (12+ chars) in your local environment');process.exit(1)
}
try {
 const hash=await argon2.hash(ADMIN_PASSWORD)
 const [result]=await pool.execute(`INSERT INTO users(full_name,email,password_hash,role) VALUES(?,?,?,'ADMIN')`,[ADMIN_NAME,ADMIN_EMAIL.trim().toLowerCase(),hash])
 console.log(`Created administrator account ID ${result.insertId}`)
} catch(error){console.error(error.code==='ER_DUP_ENTRY'?'Email already exists; no role was changed':error.message);process.exitCode=1}
finally{await pool.end()}
