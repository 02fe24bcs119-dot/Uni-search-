import { fork } from 'node:child_process'
import { join } from 'node:path'
import { claimJob, markFailure, markStage, persistIndex, recoverRunningJobs } from '../../../engine-3-persistent-index/src/repository.mjs'
import { config } from './config.mjs'
import { validateDocumentContract } from '../../../engine-1-document-processing/src/documentContract.mjs'
/** ONE API parent manages exactly THREE long-lived OS child workers using IPC. */
export function createWorkerManager(pool) {
 const slots=Array.from({length:3},(_,i)=>({id:i+1,child:null,state:'offline',job:null,timer:null,restarts:0,settling:false}))
 let running=false,pumping=false,pumpAgain=false,ticker=null,lastError=null
 let completed=0,failed=0
 async function settle(slot,job,error=null,result=null){
  if(slot.job?.id!==job.id||slot.settling)return
  slot.settling=true
  clearTimeout(slot.timer);slot.timer=null
  slot.state='indexing'
  try {
   if(error){ await markFailure(pool,job,error.message,error.retryable!==false);failed++;lastError=error.message }
   else {
    validateDocumentContract(result,job.document_id)
    await markStage(pool,job,'EXTRACTED')
    await persistIndex(pool,job,result)
    completed++
   }
  }catch(problem){lastError=problem.message;console.error('Indexing commit error:',problem)
   try{await markFailure(pool,job,problem.message,true)}catch(dbError){console.error('Could not record failure:',dbError.message)}
  }finally{
   if(slot.job?.id===job.id){slot.job=null;slot.state=slot.child?'idle':'offline';slot.settling=false}
   if(running)void pump()
  }
 }
 function spawnSlot(slot){
  if(!running)return
  slot.state='starting'
  const child=fork(config.workerFile,[],{stdio:['ignore','inherit','inherit','ipc'],env:process.env})
  slot.child=child
  child.on('message',msg=>{
   if(slot.child!==child)return
   if(msg?.type==='READY'){if(!slot.job){slot.state='idle';void pump()}return}
   const job=slot.job
   if(!job||String(msg.jobId)!==String(job.id))return
   if(msg.type==='STAGE')void markStage(pool,job,msg.stage).catch(e=>{lastError=e.message})
   if(msg.type==='RESULT')void settle(slot,job,null,msg.result)
   if(msg.type==='ERROR')void settle(slot,job,Object.assign(new Error(msg.error),{retryable:msg.retryable}),null)
  })
  child.on('error',error=>{lastError=error.message;console.error(`Worker ${slot.id} error:`,error.message)})
  child.on('exit',(code,signal)=>{
   if(slot.child!==child)return
   const interrupted=slot.job
   slot.child=null;slot.state='offline'
   clearTimeout(slot.timer);slot.timer=null
   if(interrupted)void settle(slot,interrupted,Object.assign(new Error(`Worker exited (${signal||code})`),{retryable:true}))
   if(running){slot.restarts++;slot.state='restarting';setTimeout(()=>spawnSlot(slot),1000).unref?.()}
  })
 }
 async function pump(){
  if(!running)return
  if(pumping){pumpAgain=true;return}
  pumping=true
  try {
   for(const slot of slots){
    if(slot.state!=='idle'||!slot.child||slot.job)continue
    const job=await claimJob(pool)
    if(!job)break
    slot.job=job;slot.state='busy'
    slot.timer=setTimeout(()=>{
     if(slot.job?.id===job.id){lastError=`Worker ${slot.id} timed out`;slot.child?.kill('SIGKILL')}
    },config.processTimeoutMs)
    try {
     slot.child.send({type:'PROCESS',jobId:job.id,path:join(config.uploadDir,job.stored_filename),document:job,options:{ocrEnabled:config.ocrEnabled,ocrMaxPages:config.ocrMaxPages}})
    }catch(error){void settle(slot,job,Object.assign(error,{retryable:true}))}
   }
  }catch(error){lastError=error.message;console.error('Job claim failed:',error.message)}
  finally{pumping=false;if(pumpAgain){pumpAgain=false;queueMicrotask(()=>{void pump()})}}
 }
 return {
  async start(){if(running)return;await recoverRunningJobs(pool);running=true;for(const slot of slots)spawnSlot(slot);ticker=setInterval(()=>{void pump()},1500);ticker.unref?.()},
  wake(){void pump()},
  status(){return{parent_pid:process.pid,parent_state:running?'running':'stopped',worker_count:3,
    workers:slots.map(s=>({worker:s.id,pid:s.child?.pid??null,status:s.state,job_id:s.job?.id??null,restarts:s.restarts})),
    active:slots.filter(s=>Boolean(s.job)).length,completed_this_run:completed,failed_attempts_this_run:failed,last_error:lastError}},
  async stop(){running=false;clearInterval(ticker);for(const slot of slots){clearTimeout(slot.timer);slot.child?.send({type:'SHUTDOWN'})}await new Promise(resolve=>setTimeout(resolve,2000));for(const slot of slots)if(slot.child)slot.child.kill('SIGTERM')}
 }
}
