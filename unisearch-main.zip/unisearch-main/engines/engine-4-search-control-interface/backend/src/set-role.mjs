import 'dotenv/config'
import {pool} from './database.mjs'
const [email,role]=process.argv.slice(2)
if(!email||!['STUDENT','FACULTY','ADMIN'].includes(role)){console.error('Usage: node src/set-role.mjs user@school.edu FACULTY');process.exit(1)}
try{const [r]=await pool.execute('UPDATE users SET role=? WHERE email=?',[role,email.toLowerCase()]);console.log(r.affectedRows?'Role changed successfully':'User not found')}
finally{await pool.end()}
