import argon2 from 'argon2'
import jwt from 'jsonwebtoken'
import { Router } from 'express'
import { rateLimit } from 'express-rate-limit'
import { pool } from './database.mjs'
import { config } from './config.mjs'
import { audit } from '../../../engine-3-persistent-index/src/repository.mjs'
const JWT_OPTIONS={issuer:'unidoc-mysql',audience:'unidoc-client',expiresIn:'15m'}
export const authRouter=Router()
const authLimit=rateLimit({windowMs:15*60*1000,limit:15,standardHeaders:'draft-8',legacyHeaders:false})
export async function requireAuth(req,res,next){
 try {
  const authorization=req.headers.authorization||''
  if(!authorization.startsWith('Bearer '))return res.status(401).json({success:false,message:'Login required'})
  const claims=jwt.verify(authorization.slice(7),config.jwtSecret,{issuer:JWT_OPTIONS.issuer,audience:JWT_OPTIONS.audience})
  const id=Number(claims.sub)
  if(!Number.isSafeInteger(id)||id<1)return res.status(401).json({success:false,message:'Invalid session'})
  const [rows]=await pool.execute('SELECT id,full_name,email,role,department_id FROM users WHERE id=?',[id])
  if(!rows.length)return res.status(401).json({success:false,message:'User not found'})
  req.user=rows[0];next()
 } catch(error){
  if(['TokenExpiredError','JsonWebTokenError','NotBeforeError'].includes(error.name))return res.status(401).json({success:false,message:'Session expired or invalid'})
  next(error)
 }
}
const emailPattern=/^[^\s@]+@[^\s@]+\.[^\s@]+$/
authRouter.post('/register',authLimit,async(req,res,next)=>{
 try {
  const {fullName,email,password}=req.body||{}
  if(typeof fullName!=='string'||fullName.trim().length<2||fullName.length>120||typeof email!=='string'||email.length>254||!emailPattern.test(email.trim())||typeof password!=='string'||password.length<12||password.length>256)
   return res.status(400).json({success:false,message:'Name, valid email and password of 12–256 characters required'})
  const normalized=email.trim().toLowerCase()
  const hash=await argon2.hash(password)
  let id
  try {const [result]=await pool.execute("INSERT INTO users(full_name,email,password_hash,role) VALUES (?,?,?,'STUDENT')",[fullName.trim(),normalized,hash]);id=result.insertId}
  catch(error){if(error.code==='ER_DUP_ENTRY')return res.status(409).json({success:false,message:'Email already registered'});throw error}
  await audit(pool,{actorId:id,actorEmail:normalized,action:'REGISTER',outcome:'SUCCESS'})
  return res.status(201).json({success:true,message:'Student account created'})
 }catch(error){next(error)}
})
authRouter.post('/login',authLimit,async(req,res,next)=>{
 try {
  const {email,password}=req.body||{}
  if(typeof email!=='string'||typeof password!=='string'||email.length>254)return res.status(400).json({success:false,message:'Email and password required'})
  const normalized=email.trim().toLowerCase()
  const [rows]=await pool.execute('SELECT * FROM users WHERE email=?',[normalized]);const user=rows[0]
  const valid=user&&await argon2.verify(user.password_hash,password)
  if(!valid){await audit(pool,{actorEmail:normalized,action:'LOGIN',outcome:'DENIED'});return res.status(401).json({success:false,message:'Invalid email or password'})}
  const accessToken=jwt.sign({},config.jwtSecret,{...JWT_OPTIONS,subject:String(user.id)})
  await audit(pool,{actorId:user.id,actorEmail:user.email,action:'LOGIN',outcome:'SUCCESS'})
  res.json({success:true,data:{accessToken,user:{id:user.id,full_name:user.full_name,email:user.email,role:user.role,department_id:user.department_id}}})
 }catch(error){next(error)}
})
authRouter.get('/me',requireAuth,(req,res)=>res.json({success:true,user:req.user}))
