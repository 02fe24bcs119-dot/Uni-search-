import 'dotenv/config'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import mysql from 'mysql2/promise'
import { config } from './config.mjs'
// This file intentionally runs only a trusted local SQL migration, never user-supplied SQL.
const script = await readFile(fileURLToPath(new URL('../../../engine-3-persistent-index/migrations/001_schema.sql', import.meta.url)), 'utf8')
const connection = await mysql.createConnection({ ...config.mysql, database: undefined, multipleStatements: true })
try { await connection.query(script); console.log('Migration complete: university_search (MySQL) tables created') }
finally { await connection.end() }
