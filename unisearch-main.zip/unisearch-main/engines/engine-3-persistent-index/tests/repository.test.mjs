import {test} from 'node:test'
import assert from 'node:assert/strict'
import {validId,transaction,persistIndex} from '../src/repository.mjs'

test('document id validator rejects invalid or dangerous values',()=>{
 assert.equal(validId(1),true);assert.equal(validId('53'),true)
 for(const value of [0,-3,'foo','1 OR 1=1',Number.MAX_SAFE_INTEGER+1])assert.equal(validId(value),false)
})
test('repository transaction always commits and releases on success',async()=>{
 const calls=[];const conn={beginTransaction:async()=>calls.push('BEGIN'),commit:async()=>calls.push('COMMIT'),rollback:async()=>calls.push('ROLLBACK'),release:()=>calls.push('RELEASE')}
 const result=await transaction({getConnection:async()=>conn},async()=>42)
 assert.equal(result,42);assert.deepEqual(calls,['BEGIN','COMMIT','RELEASE'])
})
test('repository transaction rolls back and releases on error',async()=>{
 const calls=[];const conn={beginTransaction:async()=>calls.push('BEGIN'),commit:async()=>calls.push('COMMIT'),rollback:async()=>calls.push('ROLLBACK'),release:()=>calls.push('RELEASE')}
 await assert.rejects(transaction({getConnection:async()=>conn},async()=>{throw new Error('failure')}),/failure/)
 assert.deepEqual(calls,['BEGIN','ROLLBACK','RELEASE'])
})
test('invalid indexing contract rejected before opening a DB transaction',async()=>{
 let connected=false
 await assert.rejects(persistIndex({getConnection:async()=>{connected=true}}, {id:1,document_id:1}, {terms:{},document_length:0,extracted_text:''}),/Invalid/)
 assert.equal(connected,false)
})
