/** Engine 3 — MySQL 8/InnoDB transactional metadata and positional postings. */
export const validId = value => Number.isSafeInteger(Number(value)) && Number(value)>0
const visible = (alias='d') => `(
  ? = 'ADMIN'
  OR ${alias}.access_level IN ('PUBLIC','UNIVERSITY')
  OR (${alias}.access_level = 'DEPARTMENT' AND ${alias}.department_id = ?)
  OR (${alias}.access_level IN ('RESTRICTED','PRIVATE') AND ${alias}.uploaded_by = ?)
)`
const permissions = u => [u.role,u.department_id??null,u.id]
export async function transaction(pool, callback) {
 const c=await pool.getConnection()
 try { await c.beginTransaction();const result=await callback(c);await c.commit();return result }
 catch(error){await c.rollback();throw error}finally{c.release()}
}
export async function audit(db,{actorId=null,actorEmail=null,action,outcome,documentId=null,details=null}){
 await db.execute(`INSERT INTO audit_events(actor_id,actor_email,action,outcome,document_id,details) VALUES(?,?,?,?,?,?)`,
 [actorId,actorEmail,action,outcome,documentId,String(details??'').slice(0,500)||null])
}
export async function listDocuments(pool,user,{onlyIndexed=false,limit=200,offset=0,filters={}}={}) {
 const where=[visible(),'1=1']
 const args=permissions(user)
 if(onlyIndexed)where.push("d.status='INDEXED'")
 if(filters.subject){where.push('d.subject=?');args.push(filters.subject)}
 if(filters.semester){where.push('d.semester=?');args.push(filters.semester)}
 if(filters.category){where.push('d.category=?');args.push(filters.category)}
 if(filters.fileType){where.push('d.mime_type=?');args.push(filters.fileType)}
 if(filters.departmentId && validId(filters.departmentId)){where.push('d.department_id=?');args.push(Number(filters.departmentId))}
 const [rows]=await pool.query(`SELECT d.id,d.title,d.description,d.subject,d.semester,d.category,
  d.original_filename,d.mime_type,d.file_size_bytes,d.file_sha256,d.department_id,d.uploaded_by,d.access_level,
  d.status,d.processing_error,d.created_at,d.updated_at,s.token_count
  FROM documents d LEFT JOIN document_statistics s ON s.document_id=d.id
  WHERE ${where.join(' AND ')} ORDER BY d.created_at DESC,d.id DESC LIMIT ? OFFSET ?`,[...args,Math.min(5000,Math.max(1,Number(limit)||200)),Math.max(0,Number(offset)||0)])
 return rows
}
export async function getDocument(pool,user,id) {
 const [rows]=await pool.execute(`SELECT d.* FROM documents d WHERE d.id=? AND ${visible()}`,[id,...permissions(user)])
 return rows[0]??null
}
/** Select only posting-list candidates for positive queries. NOT needs an authorized universe.
 * No full extracted-text scans are performed for normal keyword retrieval. */
export async function searchCandidates(pool,user,words,filters={},needsUniverse=false){
 const filtersSql=[];const filterArgs=[]
 if(filters.subject){filtersSql.push('d.subject=?');filterArgs.push(filters.subject)}
 if(filters.semester){filtersSql.push('d.semester=?');filterArgs.push(filters.semester)}
 if(filters.category){filtersSql.push('d.category=?');filterArgs.push(filters.category)}
 if(filters.fileType){filtersSql.push('d.mime_type=?');filterArgs.push(filters.fileType)}
 if(filters.departmentId&&validId(filters.departmentId)){filtersSql.push('d.department_id=?');filterArgs.push(Number(filters.departmentId))}
 const baseWhere=`d.status='INDEXED' AND ${visible()} ${filtersSql.map(f=>'AND '+f).join(' ')}`
 const [[{total}]] = await pool.query(`SELECT COUNT(*) AS total FROM documents d WHERE ${baseWhere}`,[...permissions(user),...filterArgs])
 if(!words.length)return {documents:[],total}
 const postingClause=needsUniverse?'':`AND EXISTS (
  SELECT 1 FROM postings p JOIN terms t ON t.id=p.term_id
  WHERE p.document_id=d.id AND t.term IN (${words.map(()=>'?').join(',')})
 )`
 // This query reads indexed metadata, never whole file contents. A NOT universe can be large.
 const args=[...permissions(user),...filterArgs,...(needsUniverse?[]:words)]
 const [documents]=await pool.query(`SELECT d.id,d.title,d.description,d.subject,d.semester,d.category,
 d.original_filename,d.mime_type,d.file_size_bytes,d.department_id,d.uploaded_by,d.access_level,d.created_at,
 d.status,s.token_count
 FROM documents d LEFT JOIN document_statistics s ON s.document_id=d.id
 WHERE ${baseWhere} ${postingClause} ORDER BY d.id ASC`,args)
 return {documents,total}
}

export async function getPostings(pool,terms,allowedDocumentIds){
 if(!terms.length||!allowedDocumentIds.length)return []
 const [rows]=await pool.query(`SELECT t.term,p.document_id,p.frequency,p.positions
  FROM terms t JOIN postings p ON p.term_id=t.id
  WHERE t.term IN (${terms.map(()=>'?').join(',')}) AND p.document_id IN (${allowedDocumentIds.map(()=>'?').join(',')})`,
 [...terms,...allowedDocumentIds])
 return rows.map(r=>({...r,positions:typeof r.positions==='string'?JSON.parse(r.positions):r.positions}))
}
export async function getSnippets(pool,ids){
 if(!ids.length)return new Map()
 const [rows]=await pool.query(`SELECT document_id,extracted_text FROM document_contents WHERE document_id IN (${ids.map(()=>'?').join(',')})`,ids)
 return new Map(rows.map(r=>[String(r.document_id),r.extracted_text]))
}
export async function insertDocumentAndJob(pool,doc,user){
 return transaction(pool,async c=>{
  const [record]=await c.execute(`INSERT INTO documents
  (title,description,subject,semester,category,original_filename,stored_filename,mime_type,file_size_bytes,file_sha256,uploaded_by,department_id,access_level,status)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'QUEUED')`,[
   doc.title,doc.description,doc.subject,doc.semester,doc.category,doc.originalFilename,doc.storedFilename,
   doc.mimeType,doc.size,doc.sha256,user.id,doc.departmentId,doc.accessLevel])
  const documentId=record.insertId
  await c.execute('INSERT INTO processing_jobs(document_id,state) VALUES (?,\'QUEUED\')',[documentId])
  await audit(c,{actorId:user.id,actorEmail:user.email,action:'UPLOAD',outcome:'SUCCESS',documentId})
  return {id:documentId,status:'QUEUED'}
 })
}
/** An InnoDB row lock guarantees each queued job is claimed by one worker. */
export async function claimJob(pool) {
 return transaction(pool,async c=>{
  const [rows]=await c.query(`SELECT id,document_id,attempts FROM processing_jobs
    WHERE state IN ('QUEUED','RETRY_WAIT') AND next_attempt_at<=NOW()
    ORDER BY next_attempt_at,id LIMIT 1 FOR UPDATE SKIP LOCKED`)
  const job=rows[0]
  if(!job)return null
  const [docs]=await c.execute('SELECT stored_filename,original_filename,mime_type,file_size_bytes,file_sha256,subject,semester,category,access_level,created_at FROM documents WHERE id=? FOR UPDATE',[job.document_id])
  if(!docs.length)return null
  job.attempts++
  Object.assign(job,docs[0])
  await c.execute("UPDATE processing_jobs SET state='RUNNING',attempts=?,claimed_at=NOW(),processing_ms=NULL,last_error=NULL WHERE id=?",[job.attempts,job.id])
  await c.execute("UPDATE documents SET status='PROCESSING',processing_error=NULL WHERE id=?",[job.document_id])
  return job
 })
}
export async function markStage(pool,job,stage){
 const allowed={OCR_PROCESSING:['PROCESSING'],EXTRACTED:['PROCESSING','OCR_PROCESSING'],INDEXING:['EXTRACTED']}
 if(!Object.hasOwn(allowed,stage))throw new Error('Invalid document state transition')
 const [result]=await pool.query(`UPDATE documents SET status=? WHERE id=? AND status IN (${allowed[stage].map(()=>'?').join(',')})`,[stage,job.document_id,...allowed[stage]])
 return result.affectedRows>0
}
/** Actual index replace, corpus DF update and job completion happen in ONE transaction. */
export async function persistIndex(pool,job,output){
 if(!output||typeof output.extracted_text!=='string'||!Number.isSafeInteger(output.document_length)||output.document_length<1)throw new Error('Invalid document-processing contract')
 const entries=Object.entries(output.terms||{})
 if(!entries.length||entries.length>75000)throw new Error('No usable index entries')
 return transaction(pool,async c=>{
  const [docs]=await c.execute('SELECT id FROM documents WHERE id=? FOR UPDATE',[job.document_id])
  if(!docs.length)throw new Error('Document deleted while processing')
  const [jobs]=await c.execute("SELECT state FROM processing_jobs WHERE id=? AND document_id=? FOR UPDATE",[job.id,job.document_id])
  if(!jobs.length||jobs[0].state!=='RUNNING')throw new Error('Processing job is no longer active')
  const [transition]=await c.execute("UPDATE documents SET status='INDEXING' WHERE id=? AND status='EXTRACTED'",[job.document_id])
  if(transition.affectedRows!==1)throw new Error('Invalid indexing transition; expected EXTRACTED')
  const [old]=await c.execute('SELECT term_id FROM postings WHERE document_id=?',[job.document_id])
  const affected=new Set(old.map(x=>Number(x.term_id)))
  await c.execute('DELETE FROM postings WHERE document_id=?',[job.document_id])
  const batchSize=200
  for(let i=0;i<entries.length;i+=batchSize){
   const batch=entries.slice(i,i+batchSize)
   for(const [term,positions] of batch){
    if(!term||term.length>191||!Array.isArray(positions)||!positions.length||positions.some(p=>!Number.isSafeInteger(p)||p<0||p>=output.document_length))throw new Error('Invalid positional posting')
   }
   await c.query(`INSERT IGNORE INTO terms(term) VALUES ${batch.map(()=>'(?)').join(',')}`,batch.map(([term])=>term))
   const [terms]=await c.query(`SELECT id,term FROM terms WHERE term IN (${batch.map(()=>'?').join(',')})`,batch.map(([term])=>term))
   const byWord=new Map(terms.map(t=>[t.term,Number(t.id)]))
   const rows=[]
   const args=[]
   for(const [term,positions] of batch){
    const id=byWord.get(term)
    if(!id)throw new Error('Missing dictionary term')
    affected.add(id);rows.push('(?,?,?,?)');args.push(id,job.document_id,positions.length,JSON.stringify(positions))
   }
   await c.query(`INSERT INTO postings(term_id,document_id,frequency,positions) VALUES ${rows.join(',')}`,args)
  }
  await c.execute(`INSERT INTO document_statistics(document_id,token_count,indexed_at) VALUES (?,?,NOW())
    ON DUPLICATE KEY UPDATE token_count=VALUES(token_count),indexed_at=NOW()`,[job.document_id,output.document_length])
  await c.execute(`INSERT INTO document_contents(document_id,extracted_text) VALUES (?,?)
    ON DUPLICATE KEY UPDATE extracted_text=VALUES(extracted_text)`,[job.document_id,output.extracted_text.slice(0,2_000_000)])
  for(const termId of affected)await c.execute(`UPDATE terms SET document_frequency=(SELECT COUNT(*) FROM postings WHERE term_id=?) WHERE id=?`,[termId,termId])
  await c.execute('DELETE FROM terms WHERE document_frequency=0')
  await c.execute("UPDATE documents SET status='INDEXED',processing_error=NULL WHERE id=?",[job.document_id])
  await c.execute("UPDATE processing_jobs SET state='SUCCEEDED',processing_ms=GREATEST(0,TIMESTAMPDIFF(MICROSECOND,claimed_at,NOW()) DIV 1000),claimed_at=NULL,last_error=NULL WHERE id=?",[job.id])
 })
}
export async function markFailure(pool,job,message,retryable,maxAttempts=3){
 const willRetry=retryable&&job.attempts<maxAttempts
 const clean=String(message).slice(0,500)
 return transaction(pool,async c=>{
  const [rows]=await c.execute('SELECT state FROM processing_jobs WHERE id=? FOR UPDATE',[job.id])
  if(!rows.length||rows[0].state!=='RUNNING')return
  await c.execute('INSERT INTO job_failures(job_id,attempt,error_message,retryable) VALUES (?,?,?,?)',[job.id,job.attempts,clean,Boolean(retryable)])
  await c.execute(`UPDATE processing_jobs SET state=?,last_error=?,claimed_at=NULL,next_attempt_at=DATE_ADD(NOW(),INTERVAL ? SECOND) WHERE id=?`,
   [willRetry?'RETRY_WAIT':'FAILED',clean,willRetry?Math.pow(2,job.attempts):0,job.id])
  await c.execute('UPDATE documents SET status=?,processing_error=? WHERE id=?',[willRetry?'QUEUED':'FAILED',clean,job.document_id])
 })
}
/** Startup-only recovery assumes a single API parent instance controls all three workers. */
export async function recoverRunningJobs(pool) {
 await transaction(pool,async c=>{
  const [rows]=await c.query("SELECT document_id FROM processing_jobs WHERE state='RUNNING' FOR UPDATE")
  if(!rows.length)return
  await c.query("UPDATE processing_jobs SET state='QUEUED',claimed_at=NULL,next_attempt_at=NOW(),last_error='Recovered after restart' WHERE state='RUNNING'")
  for(const row of rows)await c.execute("UPDATE documents SET status='QUEUED' WHERE id=?",[row.document_id])
 })
}
export async function requeue(pool,documentId){
 return transaction(pool,async c=>{
  const [rows]=await c.execute('SELECT status FROM documents WHERE id=? FOR UPDATE',[documentId])
  if(!rows.length)return 'missing'
  const [jobs]=await c.execute('SELECT state FROM processing_jobs WHERE document_id=? FOR UPDATE',[documentId])
  if(jobs.length&&['RUNNING','QUEUED','RETRY_WAIT'].includes(jobs[0].state))return 'busy'
  await recomputeAffected(c,documentId)
  await c.execute('DELETE FROM document_statistics WHERE document_id=?',[documentId])
  await c.execute('DELETE FROM document_contents WHERE document_id=?',[documentId])
  await c.execute(`INSERT INTO processing_jobs(document_id,state,attempts,next_attempt_at,claimed_at,last_error)
    VALUES(?,'QUEUED',0,NOW(),NULL,NULL) ON DUPLICATE KEY UPDATE
    state='QUEUED',attempts=0,next_attempt_at=NOW(),claimed_at=NULL,last_error=NULL`,[documentId])
  await c.execute("UPDATE documents SET status='QUEUED',processing_error=NULL WHERE id=?",[documentId])
  return 'queued'
 })
}
async function recomputeAffected(c,documentId){
 const [rows]=await c.execute('SELECT term_id FROM postings WHERE document_id=?',[documentId])
 await c.execute('DELETE FROM postings WHERE document_id=?',[documentId])
 for(const {term_id} of rows)await c.execute('UPDATE terms SET document_frequency=(SELECT COUNT(*) FROM postings WHERE term_id=?) WHERE id=?',[term_id,term_id])
 await c.execute('DELETE FROM terms WHERE document_frequency=0')
}
export async function updateMetadata(pool,id,metadata,user){
 return transaction(pool,async c=>{
  const [rows]=await c.execute('SELECT id FROM documents WHERE id=? FOR UPDATE',[id])
  if(!rows.length)return null
  await c.execute(`UPDATE documents SET title=?,description=?,subject=?,semester=?,category=?,access_level=?,department_id=? WHERE id=?`,
   [metadata.title,metadata.description,metadata.subject,metadata.semester,metadata.category,metadata.accessLevel,metadata.departmentId,id])
  await audit(c,{actorId:user.id,actorEmail:user.email,action:'UPDATE_METADATA',outcome:'SUCCESS',documentId:id})
  return {id,updated:true}
 })
}
export async function replaceFile(pool,id,file,user){
 return transaction(pool,async c=>{
  const [documents]=await c.execute('SELECT * FROM documents WHERE id=? FOR UPDATE',[id])
  const doc=documents[0]
  if(!doc)return {state:'missing'}
  const [jobs]=await c.execute('SELECT state FROM processing_jobs WHERE document_id=? FOR UPDATE',[id])
  if(jobs.length&&['RUNNING','QUEUED','RETRY_WAIT'].includes(jobs[0].state))return {state:'busy'}
  const [duplicates]=await c.execute('SELECT id FROM documents WHERE file_sha256=? AND id<>?',[file.sha256,id])
  if(duplicates.length)return {state:'duplicate'}
  await recomputeAffected(c,id)
  await c.execute('DELETE FROM document_statistics WHERE document_id=?',[id])
  await c.execute('DELETE FROM document_contents WHERE document_id=?',[id])
  await c.execute(`UPDATE documents SET original_filename=?,stored_filename=?,mime_type=?,file_size_bytes=?,file_sha256=?,status='QUEUED',processing_error=NULL WHERE id=?`,
  [file.originalFilename,file.storedFilename,file.mimeType,file.size,file.sha256,id])
  await c.execute(`INSERT INTO processing_jobs(document_id,state,attempts,next_attempt_at,claimed_at,last_error)
   VALUES(?,'QUEUED',0,NOW(),NULL,NULL) ON DUPLICATE KEY UPDATE state='QUEUED',attempts=0,next_attempt_at=NOW(),claimed_at=NULL,last_error=NULL`,[id])
  await audit(c,{actorId:user.id,actorEmail:user.email,action:'REPLACE',outcome:'SUCCESS',documentId:id})
  return {state:'queued',oldFilename:doc.stored_filename}
 })
}
export async function deleteDocument(pool,id,user){
 return transaction(pool,async c=>{
  const [rows]=await c.execute('SELECT stored_filename FROM documents WHERE id=? FOR UPDATE',[id])
  if(!rows.length)return {state:'missing'}
  const [jobs]=await c.execute('SELECT state FROM processing_jobs WHERE document_id=? FOR UPDATE',[id])
  if(jobs.some(j=>j.state==='RUNNING'))return {state:'busy'}
  await recomputeAffected(c,id)
  await audit(c,{actorId:user.id,actorEmail:user.email,action:'DELETE',outcome:'SUCCESS',documentId:id})
  await c.execute('DELETE FROM documents WHERE id=?',[id])
  return {state:'deleted',storedFilename:rows[0].stored_filename}
 })
}
export async function stats(pool){
 const [[counters]] = await pool.query(`SELECT COUNT(*) AS total_documents,
  SUM(status='INDEXED') AS indexed_documents,SUM(status='FAILED') AS failed_documents FROM documents`)
 const [[term]] = await pool.query('SELECT COUNT(*) AS total_terms FROM terms')
 const [[postings]] = await pool.query('SELECT COUNT(*) AS total_postings FROM postings')
 const [[jobs]] = await pool.query("SELECT SUM(state IN ('QUEUED','RETRY_WAIT')) AS queued_jobs, SUM(state='RUNNING') AS running_jobs FROM processing_jobs")
 const [states] = await pool.query('SELECT status, COUNT(*) AS count FROM documents GROUP BY status')
 const [[avg]] = await pool.query("SELECT AVG(processing_ms) AS avg_processing_ms FROM processing_jobs WHERE state='SUCCEEDED' AND processing_ms IS NOT NULL")
 return {...counters,...term,...postings,...jobs,documents:states,average_processing_ms:avg.avg_processing_ms??null}
}
export async function listJobs(pool){const [rows]=await pool.query(`SELECT j.*,d.title,d.status FROM processing_jobs j JOIN documents d ON d.id=j.document_id ORDER BY j.updated_at DESC LIMIT 100`);return rows}
export async function listFailures(pool){const [rows]=await pool.query('SELECT * FROM job_failures ORDER BY happened_at DESC LIMIT 30');return rows}
export async function listAudit(pool){const [rows]=await pool.query('SELECT * FROM audit_events ORDER BY id DESC LIMIT 100');return rows}
