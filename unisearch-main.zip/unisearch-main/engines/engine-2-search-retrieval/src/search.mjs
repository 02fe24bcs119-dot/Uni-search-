/** Engine 2 (DSA): positional inverted-index Boolean/phrase search with TF-IDF.
 * Syntax: keywords, "exact phrase", AND, OR, NOT, parentheses; adjacent operands imply AND.
 * Query state is transient. Engine 3 owns the durable posting lists.
 */
export const STOP_WORDS = new Set(['a','an','the','and','or','of','to','in','on','at','is','it','for','by','as','be','are','was','were','with'])
export function normalize(text) {
  return String(text).normalize('NFKC').toLowerCase()
}
export function tokenize(text) {
  return normalize(text).match(/[\p{L}\p{N}]+/gu) ?? []
}

export function parseQuery(query) {
  if (typeof query !== 'string' || !query.trim()) throw new Error('Enter a search query')
  if (query.length > 250) throw new Error('Query exceeds 250 characters')
  const raw = []
  let remaining = query
  const lexer = /^\s*(AND\b|OR\b|NOT\b|\(|\)|"([^"]*)"|[\p{L}\p{N}]+)/iu
  while (remaining.trim()) {
    const match = lexer.exec(remaining)
    if (!match) throw new Error('Invalid query syntax. Try: "machine learning" OR networks')
    const token = match[1]
    if (token.startsWith('"')) {
      const words = tokenize(match[2])
      if (!words.length) throw new Error('Quoted phrase cannot be empty')
      raw.push({ type: 'PHRASE', words })
    } else if (/^(AND|OR|NOT)$/i.test(token)) raw.push(token.toUpperCase())
    else if (token === '(' || token === ')') raw.push(token)
    else raw.push({ type: 'TERM', value: normalize(token) })
    remaining = remaining.slice(match[0].length)
  }
  const isOperand = (x) => typeof x === 'object' && x !== null
  const infix = []
  for (const item of raw) {
    const prev = infix.at(-1)
    if ((isOperand(prev) || prev === ')') && (isOperand(item) || item === '(' || item === 'NOT')) infix.push('AND')
    infix.push(item)
  }
  const ops = []
  const postfix = []
  const precedence = { OR: 1, AND: 2, NOT: 3 }
  for (const item of infix) {
    if (isOperand(item)) postfix.push(item)
    else if (item === '(') ops.push(item)
    else if (item === ')') {
      while (ops.length && ops.at(-1) !== '(') postfix.push({ type: 'OP', value: ops.pop() })
      if (ops.pop() !== '(') throw new Error('Unmatched closing parenthesis')
    } else {
      while (ops.length && ops.at(-1) !== '(' &&
        (precedence[ops.at(-1)] > precedence[item] || (item !== 'NOT' && precedence[ops.at(-1)] === precedence[item]))) {
        postfix.push({ type: 'OP', value: ops.pop() })
      }
      ops.push(item)
    }
  }
  while (ops.length) {
    const op = ops.pop()
    if (op === '(') throw new Error('Unmatched opening parenthesis')
    postfix.push({ type: 'OP', value: op })
  }
  let depth = 0
  for (const token of postfix) {
    if (token.type !== 'OP') depth++
    else if (token.value === 'NOT') {
      if (depth < 1) throw new Error('Invalid NOT expression')
    } else {
      if (depth < 2) throw new Error('Incomplete Boolean expression')
      depth--
    }
  }
  if (depth !== 1) throw new Error('Incomplete Boolean expression')
  const terms = [...new Set(postfix.flatMap((item) => item.type === 'TERM' ? [item.value] : item.type === 'PHRASE' ? item.words : []))]
  return { postfix, terms }
}

function matchPhrase(words, postingMaps) {
  const result = new Set()
  const first = postingMaps.get(words[0]) ?? new Map()
  for (const [id, posting] of first) {
    const startPositions = posting.positions ?? []
    if (!startPositions.length) continue
    const remainderSets = words.slice(1).map((word) => new Set(postingMaps.get(word)?.get(id)?.positions ?? []))
    if (startPositions.some((position) => remainderSets.every((positions, i) => positions.has(position + i + 1)))) result.add(id)
  }
  return result
}

export function makeSnippet(extractedText = '', queryTerms = []) {
  const text = String(extractedText || '').replace(/\s+/g, ' ').trim()
  if (!text) return ''
  const lower = normalize(text)
  const hits = queryTerms.map((term) => lower.indexOf(normalize(term))).filter((index) => index >= 0)
  const position = hits.length ? Math.min(...hits) : 0
  const start = Math.max(0, position - 70)
  const excerpt = text.slice(start, start + 210)
  return (start ? '…' : '') + excerpt + (start + 210 < text.length ? '…' : '')
}

export function searchIndex({ query, documents, postings, limit = 10, offset = 0, totalDocs = null }) {
  const parsed = parseQuery(query)
  const ready = documents.filter((doc) => doc.status === 'READY')
  const docMap = new Map(ready.map((doc) => [String(doc.id), doc]))
  const universe = new Set(docMap.keys())
  const postingMaps = new Map(parsed.terms.map((term) => [term, new Map()]))
  for (const item of postings) {
    const id = String(item.document_id)
    const term = normalize(item.term)
    if (docMap.has(id) && postingMaps.has(term)) {
      postingMaps.get(term).set(id, {
        frequency: Number(item.frequency),
        positions: item.positions ?? [],
      })
    }
  }
  const stack = []
  for (const node of parsed.postfix) {
    if (node.type === 'TERM') stack.push(new Set(postingMaps.get(node.value).keys()))
    else if (node.type === 'PHRASE') stack.push(matchPhrase(node.words, postingMaps))
    else if (node.value === 'NOT') {
      const operand = stack.pop()
      stack.push(new Set([...universe].filter((id) => !operand.has(id))))
    } else {
      const b = stack.pop()
      const a = stack.pop()
      stack.push(node.value === 'AND' ? new Set([...a].filter((id) => b.has(id))) : new Set([...a, ...b]))
    }
  }
  const matches = stack.pop() || new Set()
  const total = totalDocs == null ? ready.length : Number(totalDocs)
  const results = [...matches].map((id) => {
    let score = 0
    for (const term of parsed.terms) {
      if (STOP_WORDS.has(term)) continue
      const map = postingMaps.get(term)
      const tf = map.get(id)?.frequency ?? 0
      if (tf) score += (1 + Math.log(tf)) * Math.log(1 + (total + 1) / (map.size + 1))
    }
    const doc = docMap.get(id)
    return { ...doc, score: Number(score.toFixed(5)), snippet: makeSnippet(doc.extracted_text, parsed.terms) }
  })
  results.sort((a, b) => b.score - a.score || String(a.title).localeCompare(String(b.title)) || Number(a.id)-Number(b.id))
  const start = Math.max(0, Math.min(1000, Number(offset) || 0))
  return { count: results.length, results: results.slice(start, start + Math.max(1, Math.min(50, Number(limit) || 10))), terms: parsed.terms }
}
