import test from 'node:test'
import assert from 'node:assert/strict'
import { parseQuery, searchIndex, tokenize } from '../src/search.mjs'

const documents = [
  { id: 1, title: 'Machine Learning', status: 'READY' },
  { id: 2, title: 'Machine Security', status: 'READY' },
  { id: 3, title: 'History', status: 'READY' },
  { id: 4, title: 'Hidden', status: 'FAILED' },
]
const postings = [
  { document_id: 1, term: 'machine', frequency: 5 },
  { document_id: 1, term: 'learning', frequency: 3 },
  { document_id: 2, term: 'machine', frequency: 1 },
  { document_id: 2, term: 'security', frequency: 2 },
  { document_id: 4, term: 'machine', frequency: 100 },
]
const ids = (query, docs = documents) => searchIndex({ query, documents: docs, postings }).results.map((r) => r.id)

test('normalization matches index terms', () => assert.deepEqual(tokenize('MACHINE, learning!'), ['machine', 'learning']))
test('implicit AND', () => assert.deepEqual(ids('machine learning'), [1]))
test('AND takes priority over OR', () => assert.deepEqual(ids('history OR machine AND learning'), [1]))
test('parentheses alter Boolean grouping', () => assert.deepEqual(ids('(history OR machine) AND NOT security'), [1]))
test('NOT uses the accessible document universe', () => assert.deepEqual(ids('NOT machine'), [3]))
test('ranking favors documents with higher term frequency', () => assert.deepEqual(ids('machine'), [1, 2]))
test('failed documents are not searchable', () => assert.equal(ids('machine').includes(4), false))
test('documents removed by authorization cannot be retrieved', () => assert.deepEqual(ids('machine', documents.filter((d) => d.id !== 1)), [2]))
test('malformed expressions fail', () => assert.throws(() => parseQuery('machine AND')))

test('phrase matches only adjacent tokens with correct order', () => {
  const indexed = [
    { document_id: 1, term: 'machine', frequency: 1, positions: [0] },
    { document_id: 1, term: 'learning', frequency: 1, positions: [1] },
    { document_id: 2, term: 'machine', frequency: 1, positions: [0] },
    { document_id: 2, term: 'learning', frequency: 1, positions: [2] },
  ]
  const results = searchIndex({ query: '"machine learning"', documents, postings: indexed })
  assert.deepEqual(results.results.map((d) => d.id), [1])
})
test('phrase combines with Boolean operators and excludes unauthorized candidates', () => {
  const indexed = [
    { document_id: 1, term: 'machine', frequency: 1, positions: [0] },
    { document_id: 1, term: 'learning', frequency: 1, positions: [1] },
    { document_id: 2, term: 'security', frequency: 1, positions: [0] },
  ]
  const results = searchIndex({ query: '("machine learning" OR security) AND NOT history', documents: documents.filter((d) => d.id !== 2), postings: indexed })
  assert.deepEqual(results.results.map((d) => d.id), [1])
})
test('invalid quotation rejected', () => assert.throws(() => parseQuery('"machine learning')))

test('offset pagination returns a later slice of ranked documents',()=>{
 const documents=[{id:1,title:'A',status:'READY'},{id:2,title:'B',status:'READY'},{id:3,title:'C',status:'READY'}]
 const postings=[{term:'alpha',document_id:1,frequency:1,positions:[0]},{term:'alpha',document_id:2,frequency:1,positions:[0]},{term:'alpha',document_id:3,frequency:1,positions:[0]}]
 const page=searchIndex({query:'alpha',documents,postings,limit:1,offset:1})
 assert.equal(page.count,3);assert.equal(page.results.length,1);assert.equal(page.results[0].id,2)
})
test('stopwords are not weighted for ordinary keyword ranking',()=>{
 const documents=[{id:1,title:'A',status:'READY'},{id:2,title:'B',status:'READY'}]
 const postings=[{term:'the',document_id:1,frequency:50,positions:[0]},{term:'the',document_id:2,frequency:1,positions:[0]},
  {term:'algorithm',document_id:1,frequency:1,positions:[1]},{term:'algorithm',document_id:2,frequency:3,positions:[1,2,3]}]
 const result=searchIndex({query:'the AND algorithm',documents,postings})
 assert.equal(result.results[0].id,2)
})
